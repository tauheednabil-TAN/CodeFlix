# recommender.py - AI movie recommendation system
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import requests
import os
import random

def tfidf_recommend(query, movies_df, top_k=5):
    """
    Recommend movies based on TF-IDF and cosine similarity
    Uses title, genre, and year for matching
    """
    if len(movies_df) == 0:
        return []
    
    # Convert DataFrame to list of dictionaries if it's not already
    if isinstance(movies_df, list):
        movies = movies_df
    else:
        movies = []
        for _, row in movies_df.iterrows():
            movies.append({
                'title': row['title'] if 'title' in row else row[1],
                'genre': row['genre'] if 'genre' in row else row[2],
                'year': row['year'] if 'year' in row else row[3]
            })
    
    # Create text features for each movie
    movie_texts = []
    for movie in movies:
        text = f"{movie['title']} {movie['genre']} {movie['year']}"
        movie_texts.append(text)
    
    # Add the query to the corpus
    all_texts = movie_texts + [query]
    
    # Create TF-IDF matrix
    vectorizer = TfidfVectorizer(stop_words='english')
    tfidf_matrix = vectorizer.fit_transform(all_texts)
    
    # Calculate cosine similarity between query and all movies
    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    
    # Get top k most similar movies
    similar_indices = cosine_similarities.argsort()[0][-top_k:][::-1]
    
    recommendations = []
    for idx in similar_indices:
        if idx < len(movies):
            movie = movies[idx]
            movie['similarity_score'] = float(cosine_similarities[0][idx])
            recommendations.append(movie)
    
    return recommendations

def omdb_keyword_fallback(query, api_key=None, top_k=5):
    """
    Fallback to OMDb API for movie recommendations based on keywords
    This is used when the local database doesn't have enough matches
    """
    if not api_key:
        # Return some default movie suggestions if no API key
        return get_default_suggestions(query, top_k)
    
    try:
        # Search OMDb by keyword
        url = f"http://www.omdbapi.com/?s={query}&apikey={api_key}"
        response = requests.get(url)
        data = response.json()
        
        if data.get('Response') == 'True':
            movies = []
            for item in data['Search'][:top_k]:
                # Get detailed info for each movie
                detail_url = f"http://www.omdbapi.com/?i={item['imdbID']}&apikey={api_key}"
                detail_response = requests.get(detail_url)
                detail_data = detail_response.json()
                
                movie = {
                    'title': detail_data.get('Title', 'Unknown'),
                    'year': detail_data.get('Year', 'Unknown'),
                    'genre': detail_data.get('Genre', 'Unknown'),
                    'plot': detail_data.get('Plot', 'No description available'),
                    'type': detail_data.get('Type', 'movie')
                }
                movies.append(movie)
            
            return movies
        else:
            return get_default_suggestions(query, top_k)
            
    except Exception as e:
        print(f"OMDb API error: {e}")
        return get_default_suggestions(query, top_k)

def get_default_suggestions(query, top_k=5):
    """Provide default movie suggestions when API is unavailable"""
    # Sample movie database for fallback
    default_movies = [
        {
            'title': 'Inception',
            'year': '2010',
            'genre': 'Sci-Fi, Thriller',
            'plot': 'A thief who steals corporate secrets through dream-sharing technology.',
            'type': 'movie'
        },
        {
            'title': 'The Dark Knight',
            'year': '2008',
            'genre': 'Action, Crime, Drama',
            'plot': 'Batman faces the Joker, a criminal mastermind who seeks to undermine Batman.',
            'type': 'movie'
        },
        {
            'title': 'Interstellar',
            'year': '2014',
            'genre': 'Adventure, Drama, Sci-Fi',
            'plot': 'A team of explorers travel through a wormhole in space.',
            'type': 'movie'
        },
        {
            'title': 'The Shawshank Redemption',
            'year': '1994',
            'genre': 'Drama',
            'plot': 'Two imprisoned men bond over a number of years.',
            'type': 'movie'
        },
        {
            'title': 'Pulp Fiction',
            'year': '1994',
            'genre': 'Crime, Drama',
            'plot': 'Various interconnected stories of criminals in Los Angeles.',
            'type': 'movie'
        }
    ]
    
    # Return random sample based on query (simple keyword matching)
    query_lower = query.lower()
    filtered_movies = []
    
    for movie in default_movies:
        if (any(word in movie['genre'].lower() for word in query_lower.split()) or
            any(word in movie['title'].lower() for word in query_lower.split()) or
            'action' in query_lower and 'action' in movie['genre'].lower() or
            'comedy' in query_lower and 'comedy' in movie['genre'].lower() or
            'drama' in query_lower and 'drama' in movie['genre'].lower() or
            'sci' in query_lower and 'sci' in movie['genre'].lower()):
            filtered_movies.append(movie)
    
    if not filtered_movies:
        return random.sample(default_movies, min(top_k, len(default_movies)))
    
    return filtered_movies[:top_k]

def enrich_with_plots(movies, api_key=None):
    """
    Enrich movie data with plots from OMDb API
    If no API key, use default descriptions
    """
    if not api_key:
        # Add default plots if no API key
        for movie in movies:
            if 'plot' not in movie or not movie['plot']:
                movie['plot'] = f"A great {movie.get('genre', '')} movie from {movie.get('year', '')}."
        return movies
    
    try:
        for movie in movies:
            if 'plot' not in movie or not movie['plot']:
                # Try to get plot from OMDb
                url = f"http://www.omdbapi.com/?t={movie['title']}&y={movie.get('year', '')}&apikey={api_key}"
                response = requests.get(url)
                data = response.json()
                
                if data.get('Response') == 'True':
                    movie['plot'] = data.get('Plot', 'No description available')
                else:
                    movie['plot'] = f"A captivating {movie.get('genre', '')} story from {movie.get('year', '')}."
        
        return movies
        
    except Exception as e:
        print(f"Plot enrichment error: {e}")
        # Ensure all movies have at least a basic plot
        for movie in movies:
            if 'plot' not in movie or not movie['plot']:
                movie['plot'] = f"An engaging {movie.get('genre', '')} film from {movie.get('year', '')}."
        return movies

def recommend_similar_movies(movie_title, movies_df, top_k=5):
    """
    Recommend movies similar to a given movie title
    """
    return tfidf_recommend(movie_title, movies_df, top_k)