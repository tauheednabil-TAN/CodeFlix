import sqlite3
from datetime import datetime
import logging

# -----------------------------
# Enhanced Database Functions
# -----------------------------
def init_db():
    """Initialize the enhanced SQLite database schema only"""
    try:
        with sqlite3.connect(CONFIG['database_url']) as conn:
            c = conn.cursor()
            
            # First, check if the table exists and what columns it has
            c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='enhanced_movies'")
            table_exists = c.fetchone()
            
            if table_exists:
                # Table exists, check columns
                c.execute("PRAGMA table_info(enhanced_movies)")
                columns = [column[1] for column in c.fetchall()]
                
                # Add missing columns if they don't exist
                if 'details_id' not in columns:
                    c.execute("ALTER TABLE enhanced_movies ADD COLUMN details_id TEXT")
                if 'details_rating' not in columns:
                    c.execute("ALTER TABLE enhanced_movies ADD COLUMN details_rating TEXT")
                if 'streaming_services' not in columns:
                    c.execute("ALTER TABLE enhanced_movies ADD COLUMN streaming_services TEXT")
                if 'ticket_available' not in columns:
                    c.execute("ALTER TABLE enhanced_movies ADD COLUMN ticket_available BOOLEAN DEFAULT FALSE")
                
                # If old IMDB columns exist, migrate data and remove them
                if 'imdb_id' in columns and 'details_id' in columns:
                    c.execute("UPDATE enhanced_movies SET details_id = imdb_id WHERE details_id IS NULL")
                if 'imdb_rating' in columns and 'details_rating' in columns:
                    c.execute("UPDATE enhanced_movies SET details_rating = imdb_rating WHERE details_rating IS NULL")
                    
            else:
                # Create new table with updated schema
                c.execute('''
                    CREATE TABLE IF NOT EXISTS enhanced_movies (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        title TEXT NOT NULL,
                        genre TEXT NOT NULL,
                        year INTEGER,
                        watched BOOLEAN DEFAULT FALSE,
                        rating INTEGER DEFAULT 0,
                        review TEXT DEFAULT '',
                        details_id TEXT,
                        poster_url TEXT,
                        plot TEXT,
                        director TEXT,
                        actors TEXT,
                        runtime TEXT,
                        details_rating TEXT,
                        streaming_services TEXT,
                        ticket_available BOOLEAN DEFAULT FALSE,
                        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
            
            # Create indexes for better performance
            c.execute('CREATE INDEX IF NOT EXISTS idx_title ON enhanced_movies(title)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_genre ON enhanced_movies(genre)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_watched ON enhanced_movies(watched)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_year ON enhanced_movies(year)')
            
            # Check if database needs initial setup marker
            c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='app_metadata'")
            if not c.fetchone():
                # First time setup
                c.execute('''
                    CREATE TABLE app_metadata (
                        key TEXT PRIMARY KEY,
                        value TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                c.execute("INSERT INTO app_metadata (key, value) VALUES ('db_version', '1.0')")
                c.execute("INSERT INTO app_metadata (key, value) VALUES ('seeded', 'false')")
                conn.commit()
            
            conn.commit()
                    
    except sqlite3.Error as e:
        logging.error(f"Database initialization error: {e}")
        st.error(f"Database error: {e}")

def check_and_seed_database():
    """Separate function to check and seed if needed"""
    try:
        with sqlite3.connect(CONFIG['database_url']) as conn:
            c = conn.cursor()
            c.execute("SELECT value FROM app_metadata WHERE key = 'seeded'")
            result = c.fetchone()
            
            if result and result[0] == 'false':
                c.execute("SELECT COUNT(*) FROM enhanced_movies")
                if c.fetchone()[0] == 0:
                    st.info("🌱 Setting up sample data...")
                    if seed.seed_database(CONFIG['database_url']):
                        c.execute("UPDATE app_metadata SET value = 'true' WHERE key = 'seeded'")
                        conn.commit()
                        st.success("✅ Setup complete!")
                        return True
            return False
    except Exception as e:
        logging.error(f"Seeding error: {e}")
        return False

def safe_db_operation(operation, *args):
    """Safe database operation with error handling"""
    try:
        with sqlite3.connect(CONFIG['database_url']) as conn:
            c = conn.cursor()
            result = operation(c, *args)
            conn.commit()
            return result
    except sqlite3.Error as e:
        logging.error(f"Database operation error: {e}")
        st.error(f"Database error: {e}")
        return None

def add_movie(title, genre, year, watched=False, rating=0, review="", details_data=None):
    """Add a movie to the database with enhanced information"""
    def operation(c, title, genre, year, watched, rating, review, details_data):
        streaming_finder = EnhancedStreamingServiceFinder()
        in_theaters = streaming_finder.is_movie_in_theaters(year)
        
        if details_data:
            c.execute('''
                INSERT INTO enhanced_movies 
                (title, genre, year, watched, rating, review, details_id, poster_url, plot, director, actors, runtime, details_rating, ticket_available)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                title, genre, year, watched, rating, review,
                details_data.get('imdbID'),
                details_data.get('Poster'),
                details_data.get('Plot'),
                details_data.get('Director'),
                details_data.get('Actors'),
                details_data.get('Runtime'),
                details_data.get('imdbRating'),
                in_theaters
            ))
        else:
            c.execute('''
                INSERT INTO enhanced_movies (title, genre, year, watched, rating, review, ticket_available)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (title, genre, year, watched, rating, review, in_theaters))
        return c.lastrowid
    return safe_db_operation(operation, title, genre, year, watched, rating, review, details_data)

def get_movies_safe():
    """Safe database connection with context manager"""
    try:
        with sqlite3.connect(CONFIG['database_url']) as conn:
            c = conn.cursor()
            c.execute('SELECT * FROM enhanced_movies ORDER BY added_at DESC')
            return c.fetchall()
    except sqlite3.Error as e:
        logging.error(f"Database error in get_movies: {e}")
        st.error(f"Database error: {e}")
        return []

@st.cache_data(ttl=60)
def get_movies_paginated(page=0, page_size=20, filters=None):
    """Efficient pagination with filters"""
    try:
        with sqlite3.connect(CONFIG['database_url']) as conn:
            c = conn.cursor()
            
            # Build query with filters
            query = "SELECT * FROM enhanced_movies WHERE 1=1"
            params = []
            
            if filters:
                if filters.get('search'):
                    query += " AND (title LIKE ? OR genre LIKE ?)"
                    search_term = f"%{filters['search']}%"
                    params.extend([search_term, search_term])
                if filters.get('genre') and filters['genre'] != 'All':
                    query += " AND genre = ?"
                    params.append(filters['genre'])
                if filters.get('watched') == 'Watched':
                    query += " AND watched = 1"
                elif filters.get('watched') == 'Unwatched':
                    query += " AND watched = 0"
            
            # Get total count for pagination
            count_query = query.replace("SELECT *", "SELECT COUNT(*)")
            c.execute(count_query, params)
            total_count = c.fetchone()[0]
            
            # Add pagination
            query += " ORDER BY added_at DESC LIMIT ? OFFSET ?"
            params.extend([page_size, page * page_size])
            
            c.execute(query, params)
            return c.fetchall(), total_count
    except sqlite3.Error as e:
        logging.error(f"Database error in pagination: {e}")
        return [], 0

def update_movie(movie_id, title, genre, year, rating=0, review=""):
    """Update a movie in the database"""
    def operation(c, movie_id, title, genre, year, rating, review):
        c.execute('''
            UPDATE enhanced_movies 
            SET title = ?, genre = ?, year = ?, rating = ?, review = ?, last_modified = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (title, genre, year, rating, review, movie_id))
        return c.rowcount
    return safe_db_operation(operation, movie_id, title, genre, year, rating, review)

def delete_movie(movie_id):
    """Delete a movie from the database"""
    def operation(c, movie_id):
        c.execute('DELETE FROM enhanced_movies WHERE id = ?', (movie_id,))
        return c.rowcount
    return safe_db_operation(operation, movie_id)

def toggle_watched(movie_id):
    """Toggle watched status of a movie"""
    def operation(c, movie_id):
        # Get current status
        c.execute('SELECT watched FROM enhanced_movies WHERE id = ?', (movie_id,))
        result = c.fetchone()
        if result:
            current_status = result[0]
            # Toggle status
            c.execute('UPDATE enhanced_movies SET watched = ?, last_modified = CURRENT_TIMESTAMP WHERE id = ?', 
                     (not current_status, movie_id))
            return c.rowcount
        return 0
    return safe_db_operation(operation, movie_id)

def add_movie_rating(movie_id, rating, review=""):
    """Add user rating and review for a movie"""
    def operation(c, movie_id, rating, review):
        c.execute('''
            UPDATE enhanced_movies 
            SET rating = ?, review = ?, last_modified = CURRENT_TIMESTAMP 
            WHERE id = ?
        ''', (rating, review, movie_id))
        return c.rowcount
    return safe_db_operation(operation, movie_id, rating, review)

def get_stats():
    """Get enhanced movie statistics"""
    movies = get_movies_safe()
    if not movies:
        return {
            'total_movies': 0,
            'watched_count': 0,
            'completion_rate': 0,
            'unique_genres': 0,
            'average_rating': 0,
            'in_theaters_count': 0
        }
    
    total_movies = len(movies)
    watched_count = sum(1 for movie in movies if len(movie) > 4 and movie[4] == 1)
    completion_rate = (watched_count / total_movies * 100) if total_movies > 0 else 0
    unique_genres = len(set(movie[2] for movie in movies if len(movie) > 2))
    in_theaters_count = sum(1 for movie in movies if len(movie) > 15 and movie[15] == 1)
    
    # Calculate average rating (excluding unrated movies)
    ratings = [movie[5] for movie in movies if len(movie) > 5 and movie[5] > 0]
    average_rating = sum(ratings) / len(ratings) if ratings else 0
    
    return {
        'total_movies': total_movies,
        'watched_count': watched_count,
        'completion_rate': completion_rate,
        'unique_genres': unique_genres,
        'average_rating': average_rating,
        'in_theaters_count': in_theaters_count
    }
