# CodeFlix — Streamlit Movie Watchlist

## Quick Start
```bash
pip install -r requirements.txt
python seed.py
streamlit run app.py
```

### Optional (OMDb for AI Finder)
Set an environment variable `OMDB_API_KEY` for better fallback results and plots.

**macOS/Linux:**
```bash
export OMDB_API_KEY=your_key_here
```
**Windows (PowerShell):**
```powershell
setx OMDB_API_KEY "your_key_here"
```

Enjoy!
