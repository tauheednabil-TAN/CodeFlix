import streamlit as st
import pandas as pd
import plotly.express as px
# If some components use pandas or plotly, import them here too:

# If some components use CONFIG or MOVIE_DATABASE/constants, we will import them later if needed.


# -----------------------------
# Enhanced Movie Card Component with Streaming Integration
# -----------------------------
def create_movie_card(movie, key_suffix=""):
    """Create a clickable movie card with enhanced features"""
    if len(movie) < 6:
        return
    
    movie_id = movie[0]
    title = movie[1]
    genre = movie[2]
    year = movie[3]
    watched = movie[4] == 1
    rating = movie[5] if len(movie) > 5 else 0
    review = movie[6] if len(movie) > 6 else ""
    details_id = movie[7] if len(movie) > 7 else None
    poster_url = movie[8] if len(movie) > 8 else None
    plot = movie[9] if len(movie) > 9 else ""
    director = movie[10] if len(movie) > 10 else ""
    actors = movie[11] if len(movie) > 11 else ""
    runtime = movie[12] if len(movie) > 12 else ""
    details_rating = movie[13] if len(movie) > 13 else ""
    ticket_available = movie[15] if len(movie) > 15 else False
    added_date = movie[16] if len(movie) > 16 else ""
    
    # Initialize streaming finder
    streaming_finder = EnhancedStreamingServiceFinder()
    
    # Get app state
    app_state = st.session_state.app_state
    
    # Create card container
    with st.container():
        st.markdown(f'<div class="movie-card">', unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns([3, 1, 1])
        
        with col1:
            status_icon = "✅" if watched else "⏳"
            st.markdown(f"### {status_icon} {title} ({year})")
            st.markdown(f"**Genre:** {genre}")
            
            # Display rating stars
            if rating > 0:
                stars = "★" * rating + "☆" * (5 - rating)
                st.markdown(f"**Your Rating:** <span class='star-rating'>{stars}</span>", unsafe_allow_html=True)
            
            if details_rating and details_rating != "N/A":
                st.markdown(f'<span class="rating-badge">IMDB: {details_rating}</span>', unsafe_allow_html=True)
            
            if added_date:
                st.markdown(f"**Added:** {added_date[:10]}")
            
            # Quick streaming info
            watch_options = streaming_finder.get_watch_options(title, year, genre)
            available_streaming = [s for s in watch_options['streaming'].values() if s['available']]
            if available_streaming:
                service_names = [s['name'] for s in available_streaming[:2]]
                st.markdown(f"**Available on:** {', '.join(service_names)}")
            
            if ticket_available:
                st.markdown("🎟️ **In Theaters Now**")
            
            # Quick Watch Options
            if st.button("🎯 Watch Now", key=f"watch_now_{movie_id}_{key_suffix}", use_container_width=True, type="primary"):
                app_state.show_watch_options.add(movie_id)
                st.rerun()
            
            # Details Button
            if st.button("🔍 Details", key=f"details_{movie_id}_{key_suffix}", use_container_width=True):
                app_state.show_details.add(movie_id)
                st.rerun()
        
        with col2:
            # Display poster if available
            if poster_url and poster_url != "N/A":
                st.image(poster_url, use_column_width=True)
            else:
                st.markdown("🎭 *No poster*")
        
        with col3:
            st.markdown("### ")
            # Action buttons
            button_text = "⏳ Unwatch" if watched else "✅ Watch"
            button_color = "secondary" if watched else "primary"
            if st.button(button_text, key=f"watch_{movie_id}_{key_suffix}", 
                        use_container_width=True, type=button_color):
                toggle_watched(movie_id)
                st.rerun()
            
            if st.button("⭐ Rate", key=f"rate_{movie_id}_{key_suffix}", 
                        use_container_width=True, type="secondary"):
                app_state.show_rating.add(movie_id)
                st.rerun()
            
            if st.button("🗑️ Delete", key=f"delete_{movie_id}_{key_suffix}", 
                        use_container_width=True, type="secondary"):
                delete_movie(movie_id)
                st.success(f"Deleted {title} from collection!")
                st.rerun()
        
        # Watch Options Section
        if movie_id in app_state.show_watch_options:
            display_watch_options_section(title, year, genre, movie_id, key_suffix)
        
        # Rating Section
        if movie_id in app_state.show_rating:
            with st.container():
                st.markdown("---")
                st.markdown("#### ⭐ Rate this Movie")
                col_rate1, col_rate2 = st.columns([2, 1])
                with col_rate1:
                    new_rating = st.slider("Your Rating", 1, 5, rating, key=f"slider_{movie_id}")
                    review_text = st.text_area("Your Review (optional)", review, key=f"review_{movie_id}")
                with col_rate2:
                    st.markdown("### ")
                    if st.button("💾 Save Rating", key=f"save_rating_{movie_id}", use_container_width=True, type="primary"):
                        add_movie_rating(movie_id, new_rating, review_text)
                        app_state.show_rating.discard(movie_id)
                        st.success("Rating saved!")
                        st.rerun()
                    if st.button("❌ Cancel", key=f"cancel_rating_{movie_id}", use_container_width=True):
                        app_state.show_rating.discard(movie_id)
                        st.rerun()
        
        # Details Section
        if movie_id in app_state.show_details:
            display_details_section(title, year, movie_id, key_suffix)
        
        st.markdown('</div>', unsafe_allow_html=True)

def display_watch_options_section(title, year, genre, movie_id, key_suffix):
    """Display streaming and ticketing options for a movie"""
    streaming_finder = EnhancedStreamingServiceFinder()
    
    with st.spinner("🔍 Finding where to watch..."):
        watch_options = streaming_finder.get_watch_options(title, year, genre)
    
    with st.container():
        st.markdown('<div class="watch-now-section">', unsafe_allow_html=True)
        st.markdown("### 🎯 Where to Watch")
        
        # Streaming Services
        st.markdown("#### 📺 Streaming Services")
        streaming_cols = st.columns(3)
        col_idx = 0
        
        available_services = [s for s in watch_options['streaming'].values() if s['available']]
        unavailable_services = [s for s in watch_options['streaming'].values() if not s['available']]
        
        if available_services:
            for service in available_services:
                with streaming_cols[col_idx % 3]:
                    badge_class = "available-service"
                    if service['name'] == 'Crunchyroll':
                        badge_class = "anime-service"
                    badge_html = f"""
                    <a href="{service['url']}" target="_blank" style="text-decoration: none;">
                        <div class="streaming-badge {badge_class}" style="border-color: {service['color']};">
                            {service['icon']} {service['name']} ✅
                        </div>
                    </a>
                    """
                    st.markdown(badge_html, unsafe_allow_html=True)
                col_idx += 1
        else:
            st.info("No streaming services found for this movie.")
        
        # Anime Services
        if 'anime' in watch_options:
            st.markdown("#### 🍥 Anime Streaming")
            anime_cols = st.columns(2)
            for service in watch_options['anime'].values():
                with anime_cols[0]:
                    badge_html = f"""
                    <a href="{service['url']}" target="_blank" style="text-decoration: none;">
                        <div class="streaming-badge anime-service">
                            {service['icon']} {service['name']} ✅
                        </div>
                    </a>
                    """
                    st.markdown(badge_html, unsafe_allow_html=True)
        
        # Ticketing Services (if movie is in theaters)
        if watch_options['in_theaters'] and watch_options['ticketing']:
            st.markdown("#### 🎟️ Buy Tickets")
            ticket_cols = st.columns(2)
            col_idx = 0
            
            for service in watch_options['ticketing'].values():
                with ticket_cols[col_idx % 2]:
                    badge_html = f"""
                    <a href="{service['url']}" target="_blank" style="text-decoration: none;">
                        <div class="streaming-badge ticket-service">
                            {service['icon']} {service['name']}
                        </div>
                    </a>
                    """
                    st.markdown(badge_html, unsafe_allow_html=True)
                col_idx += 1
        
        # Alternative options
        st.markdown("#### 🔍 Other Options")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            justwatch_url = f"https://www.justwatch.com/us/search?q={quote(title)}"
            st.markdown(f'<a href="{justwatch_url}" target="_blank"><div class="streaming-badge available-service">🔍 JustWatch</div></a>', unsafe_allow_html=True)
        
        with col2:
            google_url = f"https://www.google.com/search?q={quote(title)}+streaming"
            st.markdown(f'<a href="{google_url}" target="_blank"><div class="streaming-badge available-service">🌐 Google Search</div></a>', unsafe_allow_html=True)
        
        with col3:
            youtube_url = f"https://www.youtube.com/results?search_query={quote(title + ' trailer')}"
            st.markdown(f'<a href="{youtube_url}" target="_blank"><div class="streaming-badge available-service">📺 Trailer</div></a>', unsafe_allow_html=True)
        
        # Close button
        app_state = st.session_state.app_state
        if st.button("Close Watch Options", key=f"close_watch_{movie_id}_{key_suffix}", use_container_width=True, type="secondary"):
            app_state.show_watch_options.discard(movie_id)
            st.rerun()
        
        st.markdown('</div>', unsafe_allow_html=True)

def display_details_section(title, year, movie_id, key_suffix):
    """Display OMDB details for a movie"""
    omdb = RateLimitedOMDbAPI()
    with st.spinner("🎬 Fetching movie details..."):
        movie_data = omdb.get_movie_with_streaming_info(title, year)
    
    if movie_data:
        with st.container():
            st.markdown('<div class="movie-detail-card">', unsafe_allow_html=True)
            st.markdown("### 🎬 Movie Details")
            
            col1, col2 = st.columns([1, 2])
            
            with col1:
                # Display poster if available
                if movie_data.get("Poster") and movie_data["Poster"] != "N/A":
                    st.image(movie_data["Poster"], use_column_width=True)
                else:
                    st.markdown("🎭 *No poster available*")
                
                # Quick Watch Button
                if st.button("🎯 Watch Now", key=f"details_watch_{movie_id}", use_container_width=True, type="primary"):
                    st.session_state.app_state.show_watch_options.add(movie_id)
                    st.rerun()
            
            with col2:
                # Movie information
                st.markdown(f"**Title:** {movie_data.get('Title', 'N/A')}")
                st.markdown(f"**Year:** {movie_data.get('Year', 'N/A')}")
                st.markdown(f"**Rated:** {movie_data.get('Rated', 'N/A')}")
                st.markdown(f"**Runtime:** {movie_data.get('Runtime', 'N/A')}")
                st.markdown(f"**Genre:** {movie_data.get('Genre', 'N/A')}")
                st.markdown(f"**Director:** {movie_data.get('Director', 'N/A')}")
                st.markdown(f"**Actors:** {movie_data.get('Actors', 'N/A')}")
                
                # Ratings with enhanced display
                ratings = movie_data.get('Ratings', [])
                if ratings:
                    st.markdown("**Ratings:**")
                    for rating in ratings:
                        source = rating.get('Source', '')
                        value = rating.get('Value', '')
                        if 'Internet Movie Database' in source:
                            st.markdown(f'<span class="rating-badge">🎬 IMDB: {value}</span>', unsafe_allow_html=True)
                        elif 'Rotten Tomatoes' in source:
                            st.markdown(f'<span style="color: #FF6B6B">🍅 Rotten Tomatoes: {value}</span>', unsafe_allow_html=True)
                        elif 'Metacritic' in source:
                            st.markdown(f'<span style="color: #4D96FF">💎 Metacritic: {value}</span>', unsafe_allow_html=True)
                
                # IMDB Rating (if available separately)
                imdb_rating = movie_data.get('imdbRating', 'N/A')
                if imdb_rating != 'N/A':
                    st.markdown(f'<span class="rating-badge">⭐ IMDB Rating: {imdb_rating}/10</span>', unsafe_allow_html=True)
                
                st.markdown(f"**Plot:** {movie_data.get('Plot', 'N/A')}")
            
            # Streaming information if available
            if 'streaming_info' in movie_data:
                streaming_info = movie_data['streaming_info']
                available_streaming = [s for s in streaming_info['streaming'].values() if s['available']]
                
                if available_streaming:
                    st.markdown("#### 📺 Available On")
                    stream_cols = st.columns(min(4, len(available_streaming)))
                    for idx, service in enumerate(available_streaming):
                        with stream_cols[idx % len(stream_cols)]:
                            st.markdown(f"""
                            <div style="text-align: center; padding: 10px; border-radius: 10px; background: {service['color']}20; border: 1px solid {service['color']}50;">
                                <div style="font-size: 1.5em;">{service['icon']}</div>
                                <div><strong>{service['name']}</strong></div>
                                <a href="{service['url']}" target="_blank" style="color: {service['color']}; text-decoration: none;">Watch →</a>
                            </div>
                            """, unsafe_allow_html=True)
            
            # Close button
            app_state = st.session_state.app_state
            if st.button("Close Details", key=f"close_{movie_id}_{key_suffix}", use_container_width=True, type="secondary"):
                app_state.show_details.discard(movie_id)
                st.rerun()
            
            st.markdown('</div>', unsafe_allow_html=True)
    else:
        st.error("❌ Could not fetch movie details. Please try again.")
def display_enhanced_search_result(item, item_type, index):
    """Display enhanced search results with OMDB details and streaming options"""
    with st.container():
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        
        col_a, col_b, col_c = st.columns([3, 1, 1])
        
        with col_a:
            title = item.get('Title') if item_type == 'movie' else item.get('title')
            year = item.get('Year') if item_type == 'movie' else item.get('year')
            genre = item.get('Genre') if item_type == 'movie' else item.get('genre')
            
            st.markdown(f"#### {title} ({year})")
            st.markdown(f"**Type:** {item_type.title()} | **Genre:** {genre}")
            
            # Get detailed movie information from OMDB
            if item_type == 'movie':
                omdb = RateLimitedOMDbAPI()
                with st.spinner(f"Fetching details for {title}..."):
                    movie_details = omdb.get_movie_details(title, int(year) if year and year.isdigit() else None)
                
                if movie_details:
                    # Display ratings
                    ratings = movie_details.get('Ratings', [])
                    imdb_rating = movie_details.get('imdbRating', 'N/A')
                    
                    if imdb_rating != 'N/A':
                        st.markdown(f'<span class="rating-badge">⭐ IMDB: {imdb_rating}/10</span>', unsafe_allow_html=True)
                    
                    # Display other ratings
                    for rating in ratings:
                        source = rating.get('Source', '')
                        value = rating.get('Value', '')
                        if 'Rotten Tomatoes' in source:
                            st.markdown(f'<span style="color: #FF6B6B">🍅 {value}</span>', unsafe_allow_html=True)
                    
                    # Display other details
                    if movie_details.get('Director') and movie_details['Director'] != 'N/A':
                        st.markdown(f"**Director:** {movie_details['Director']}")
                    if movie_details.get('Runtime') and movie_details['Runtime'] != 'N/A':
                        st.markdown(f"**Runtime:** {movie_details['Runtime']}")
                    if movie_details.get('Plot') and movie_details['Plot'] != 'N/A':
                        plot_preview = movie_details['Plot'][:100] + "..." if len(movie_details['Plot']) > 100 else movie_details['Plot']
                        st.markdown(f"**Plot:** {plot_preview}")
            
            # Show streaming availability
            streaming_finder = EnhancedStreamingServiceFinder()
            watch_options = streaming_finder.get_watch_options(title, int(year) if year and year.isdigit() else 2023, genre)
            
            # Display available services
            available_services = []
            for service_type, services in watch_options.items():
                if service_type == 'streaming':
                    available_services.extend([s for s in services.values() if s['available']])
                elif service_type == 'anime':
                    available_services.extend(services.values())
            
            if available_services:
                service_names = [f"{s['icon']} {s['name']}" for s in available_services[:2]]
                st.markdown(f"**Available on:** {', '.join(service_names)}")
        
        with col_b:
            # Display poster if available
            poster = item.get('Poster')
            if poster and poster != "N/A":
                st.image(poster, width=80)
            else:
                # Try to get poster from OMDB details
                if item_type == 'movie':
                    omdb = RateLimitedOMDbAPI()
                    movie_details = omdb.get_movie_details(title, int(year) if year and year.isdigit() else None)
                    if movie_details and movie_details.get('Poster') and movie_details['Poster'] != 'N/A':
                        st.image(movie_details['Poster'], width=80)
                    else:
                        st.markdown("🎭 *No poster*")
                else:
                    st.markdown("🎭 *No poster*")
        
        with col_c:
            if st.button("➕ Add", key=f"add_{item_type}_{index}", use_container_width=True, type="primary"):
                # Extract year properly
                year_str = year
                if year_str and isinstance(year_str, str):
                    year_val = int(''.join(filter(str.isdigit, year_str))[:4]) if any(c.isdigit() for c in year_str) else 2023
                else:
                    year_val = year if year else 2023
                
                # Get detailed movie data for storage
                omdb = RateLimitedOMDbAPI()
                details_data = None
                if item_type == 'movie':
                    details_data = omdb.get_movie_details(title, year_val)
                
                # Add to collection
                add_movie(
                    title=title,
                    genre=genre or "Unknown",
                    year=year_val,
                    watched=False,
                    details_data=details_data
                )
                st.success(f"Added {title} to collection!")
                st.rerun()
            
            if st.button("🎯 Watch", key=f"watch_{item_type}_{index}", use_container_width=True, type="secondary"):
                st.session_state[f"show_watch_{title}"] = True
            
            if st.button("🔍 Details", key=f"details_{item_type}_{index}", use_container_width=True, type="secondary"):
                st.session_state[f"show_full_details_{title}"] = True
        
        # Show watch options if triggered
        if st.session_state.get(f"show_watch_{title}"):
            year_val = int(year) if year and year.isdigit() else 2023
            display_watch_options_section(title, year_val, genre or "Unknown", f"search_{index}", f"search_{index}")
        
        # Show full details if triggered
        if st.session_state.get(f"show_full_details_{title}"):
            year_val = int(year) if year and year.isdigit() else 2023
            display_full_movie_details(title, year_val, f"search_{index}")
        
        st.markdown('</div>', unsafe_allow_html=True)
def display_full_movie_details(title, year, key_suffix):
    """Display full movie details from OMDB"""
    omdb = RateLimitedOMDbAPI()
    with st.spinner("🎬 Fetching complete movie details..."):
        movie_data = omdb.get_movie_details(title, year)
    
    if movie_data:
        with st.container():
            st.markdown('<div class="movie-detail-card">', unsafe_allow_html=True)
            st.markdown("### 🎬 Complete Movie Details")
            
            col1, col2 = st.columns([1, 2])
            
            with col1:
                # Display poster if available
                if movie_data.get("Poster") and movie_data["Poster"] != "N/A":
                    st.image(movie_data["Poster"], use_column_width=True)
                else:
                    st.markdown("🎭 *No poster available*")
            
            with col2:
                # Comprehensive movie information
                st.markdown(f"**Title:** {movie_data.get('Title', 'N/A')}")
                st.markdown(f"**Year:** {movie_data.get('Year', 'N/A')}")
                st.markdown(f"**Rated:** {movie_data.get('Rated', 'N/A')}")
                st.markdown(f"**Released:** {movie_data.get('Released', 'N/A')}")
                st.markdown(f"**Runtime:** {movie_data.get('Runtime', 'N/A')}")
                st.markdown(f"**Genre:** {movie_data.get('Genre', 'N/A')}")
                st.markdown(f"**Director:** {movie_data.get('Director', 'N/A')}")
                st.markdown(f"**Writer:** {movie_data.get('Writer', 'N/A')}")
                st.markdown(f"**Actors:** {movie_data.get('Actors', 'N/A')}")
                st.markdown(f"**Language:** {movie_data.get('Language', 'N/A')}")
                st.markdown(f"**Country:** {movie_data.get('Country', 'N/A')}")
                st.markdown(f"**Awards:** {movie_data.get('Awards', 'N/A')}")
                
                # Enhanced ratings display
                ratings = movie_data.get('Ratings', [])
                if ratings:
                    st.markdown("**Ratings:**")
                    for rating in ratings:
                        source = rating.get('Source', '')
                        value = rating.get('Value', '')
                        if 'Internet Movie Database' in source:
                            st.markdown(f'<span class="rating-badge">🎬 IMDB: {value}</span>', unsafe_allow_html=True)
                        elif 'Rotten Tomatoes' in source:
                            st.markdown(f'<span style="color: #FF6B6B; font-weight: bold;">🍅 Rotten Tomatoes: {value}</span>', unsafe_allow_html=True)
                        elif 'Metacritic' in source:
                            st.markdown(f'<span style="color: #4D96FF; font-weight: bold;">💎 Metacritic: {value}</span>', unsafe_allow_html=True)
                
                # IMDB specific ratings
                imdb_rating = movie_data.get('imdbRating', 'N/A')
                imdb_votes = movie_data.get('imdbVotes', 'N/A')
                if imdb_rating != 'N/A':
                    st.markdown(f'<span class="rating-badge">⭐ IMDB Rating: {imdb_rating}/10 ({imdb_votes} votes)</span>', unsafe_allow_html=True)
                
                # Box office information
                if movie_data.get('BoxOffice') and movie_data['BoxOffice'] != 'N/A':
                    st.markdown(f"**Box Office:** {movie_data['BoxOffice']}")
                
                st.markdown(f"**Plot:** {movie_data.get('Plot', 'N/A')}")
            
            # Close button
            if st.button("Close Details", key=f"close_full_{key_suffix}", use_container_width=True, type="secondary"):
                st.session_state[f"show_full_details_{title}"] = False
                st.rerun()
            
            st.markdown('</div>', unsafe_allow_html=True)

def show_popular_content():
    """Show popular streaming and theater content"""
    st.markdown("### 🔥 POPULAR RIGHT NOW")
    
    # Popular on Streaming
    st.markdown("#### 📺 POPULAR ON STREAMING")
    streaming_movies = [m for m in MOVIE_DATABASE if m.get('streaming_service') and not m.get('in_theaters', False)]
    
    cols = st.columns(3)
    for idx, movie in enumerate(streaming_movies[:6]):
        with cols[idx % 3]:
            st.markdown(f"**{movie['title']}**")
            st.markdown(f"*{movie['streaming_service']}*")
            if st.button("Add", key=f"stream_{idx}", use_container_width=True, type="primary"):
                add_movie(movie['title'], movie['genre'], movie['year'], False)
                st.success(f"Added {movie['title']}!")
    
    # In Theaters
    st.markdown("#### 🎟️ IN THEATERS NOW")
    theater_movies = [m for m in MOVIE_DATABASE if m.get('in_theaters', False)]
    
    theater_cols = st.columns(2)
    for idx, movie in enumerate(theater_movies[:4]):
        with theater_cols[idx % 2]:
            st.markdown(f"**{movie['title']}** ({movie['year']})")
            st.markdown(f"*{movie['genre']}*")
            if st.button("Get Tickets", key=f"theater_btn_{idx}", use_container_width=True, type="primary"):
                streaming_finder = EnhancedStreamingServiceFinder()
                watch_options = streaming_finder.get_watch_options(movie['title'], movie['year'], movie['genre'])
                st.session_state[f"show_tickets_{movie['title']}"] = True

def show_search_recommendations(query):
    """Show recommendations when no results found"""
    st.markdown("### 💡 TRY THESE POPULAR TITLES")
    
    # Get recommendations based on query
    recommendations = []
    query_lower = query.lower()
    
    # Genre-based recommendations
    genre_keywords = {
        'action': ['action', 'adventure', 'thriller', 'fight'],
        'comedy': ['comedy', 'funny', 'humor'],
        'drama': ['drama', 'emotional', 'serious'],
        'anime': ['anime', 'manga', 'japanese'],
        'horror': ['horror', 'scary', 'terror']
    }
    
    for genre, keywords in genre_keywords.items():
        if any(keyword in query_lower for keyword in keywords):
            genre_movies = [m for m in MOVIE_DATABASE if m['genre'].lower() == genre]
            recommendations.extend(genre_movies[:2])
    
    # If no genre match, show general popular movies
    if not recommendations:
        recommendations = [m for m in MOVIE_DATABASE if m.get('streaming_service')][:6]
    
    rec_cols = st.columns(3)
    for idx, movie in enumerate(recommendations):
        with rec_cols[idx % 3]:
            st.markdown(f"**{movie['title']}** ({movie['year']})")
            if st.button("Add", key=f"rec_{idx}", use_container_width=True, type="primary"):
                add_movie(movie['title'], movie['genre'], movie['year'], False)
                st.success(f"Added {movie['title']}!")
