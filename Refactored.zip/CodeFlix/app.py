import os
import sqlite3
from datetime import datetime, timedelta
import random
import requests
import json
import base64
import io
from PIL import Image
import time
import plotly.express as px
import plotly.graph_objects as go
import plotly.subplots as sp
import pandas as pd
import streamlit as st
from matplotlib import pyplot as plt
import matplotlib.colors as mcolors
from urllib.parse import quote
import logging
import threading
from functools import lru_cache, wraps
import hashlib
import html
import re
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, Set
from state import init_session_state
from state import init_session_state, AppState
from db import (
    init_db,
    check_and_seed_database,
    safe_db_operation,
    add_movie,
    get_movies_safe,
    get_movies_paginated,
    update_movie,
    delete_movie,
    toggle_watched,
    add_movie_rating,
    get_stats,
)
from services.anime_service import AnimeIntegration
from services.streaming_service import StreamingServiceFinder, EnhancedStreamingServiceFinder
from services.omdb_service import RateLimitedOMDbAPI
from services.ai_gemini import GeminiMovieChat
from ui.components import (
    create_movie_card,
    display_enhanced_search_result,
    display_details_section,
    display_watch_options_section,
    display_full_movie_details,
    show_popular_content,
    show_search_recommendations,
)
from pages.dashboard_page import show_dashboard
from pages.collection_page import show_collection_page, show_add_movies_page
from pages.streaming_page import show_streaming_page
from pages.ai_finder_page import show_enhanced_ai_finder_page
from pages.analytics_page import show_analytics_page


def get_config():
    """Get configuration from environment or secrets with fallback"""
    try:
        # Try to get from secrets, with fallback values
        omdb_api_key = st.secrets.get("OMDB_API_KEY", "9771bb71")
        gemini_api_key = st.secrets.get("GEMINI_API_KEY", "")  # 🔑 NEW
        database_url = st.secrets.get("DATABASE_URL", "movies.db")
        debug_mode = st.secrets.get("DEBUG", "false").lower() == 'true'
        cache_timeout = int(st.secrets.get("CACHE_TIMEOUT", "300"))
        max_retries = int(st.secrets.get("MAX_RETRIES", "3"))
        
        return {
            'omdb_api_key': omdb_api_key,
            'gemini_api_key': gemini_api_key,   # 🔑 NEW
            'database_url': database_url,
            'debug_mode': debug_mode,
            'cache_timeout': cache_timeout,
            'max_retries': max_retries
        }
    except Exception as e:
        logging.warning(f"Could not load secrets, using default values: {e}")
        # Fallback configuration
        return {
            'omdb_api_key': "9771bb71",  # Default API key
            'gemini_api_key': "",        # 🔑 NEW
            'database_url': "movies.db",
            'debug_mode': False,
            'cache_timeout': 300,
            'max_retries': 3
        }


# Global CONFIG object – imported everywhere else
CONFIG = get_config()


def check_environment():
    """Check if all required environment variables and secrets are available"""
    try:
        # Test if we can access secrets
        test_key = st.secrets.get("OMDB_API_KEY", None)
        
        if test_key is None:
            st.warning("⚠️ No secrets.toml file found. Using default configuration.")
            st.info("""
            For better experience, create a `.streamlit/secrets.toml` file with:
            
            ```toml
            OMDB_API_KEY = "your_omdb_api_key_here"
            DATABASE_URL = "movies.db"
            DEBUG = "false"
            CACHE_TIMEOUT = "300"
            MAX_RETRIES = "3"
            ```
            
            Get a free OMDB API key from: http://www.omdbapi.com/apikey.aspx
            """)
            return True  # Continue with default values
        
        # Test OMDB API key
        omdb = RateLimitedOMDbAPI()
        if not omdb.validate_api_key():
            st.warning("⚠️ OMDB API key appears to be invalid. Some features may not work properly.")
        
        return True
        
    except Exception as e:
        st.warning(f"⚠️ Configuration issue: {e}. Using default settings.")
        return True  # Continue with default values


# Custom Exceptions
class MovieError(Exception):
    """Base exception for movie operations"""
    pass

class DatabaseError(MovieError):
    """Database operation failed"""
    pass

class APIError(MovieError):
    """External API call failed"""
    pass

# Import seed module
try:
    import seed
    # Test if the module loaded correctly
    print("✅ seed.py imported successfully!")
except ImportError as e:
    print(f"❌ Error importing seed: {e}")
    # Create a dummy module to prevent crashes
    class DummySeed:
        def get_sample_movies(self): 
            return []
        def seed_database(self, db_path): 
            print("Seed module not available - using fallback")
            return False
        def clear_database(self, db_path): 
            return False
    
    seed = DummySeed()

# -----------------------------
# Configuration and Logging
# -----------------------------
def setup_logging():
    """Setup application logging"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('codeflix.log')
        ]
    )


# -----------------------------
# Caching and Performance Optimizations
# -----------------------------
@st.cache_data(ttl=3600)  # Cache for 1 hour
def get_movie_details_cached(title: str, year: int = None) -> dict:
    """Cached movie details"""
    omdb = RateLimitedOMDbAPI()
    return omdb.get_movie_details(title, year)

@st.cache_data(ttl=300)  # Cache for 5 minutes
def get_streaming_availability_cached(title: str, year: int, genre: str):
    """Cached streaming info"""
    streaming_finder = EnhancedStreamingServiceFinder()
    return streaming_finder.get_watch_options(title, year, genre)

@st.cache_data(ttl=60)  # Cache for 1 minute
def create_analytics_charts_cached(movie_data_hash: str):
    """Cache analytics charts using data hash"""
    movies_data = get_movies_safe()
    return create_advanced_analytics_charts(movies_data)

# Cached OMDB searches
@lru_cache(maxsize=100)
def cached_omdb_search(query, search_type):
    """Cache OMDB search results to reduce API calls"""
    omdb = RateLimitedOMDbAPI()
    return omdb.search_movies(query, search_type)

# -----------------------------
# Enhanced Movie Database with Real Streaming Content
# -----------------------------
def get_enhanced_movie_database():
    """Return enhanced movie database with real streaming content"""
    enhanced_db = [
        # Netflix Originals (Really streaming on Netflix)
        {"title": "The Gray Man", "genre": "Action", "year": 2022, "streaming_service": "Netflix"},
        {"title": "Red Notice", "genre": "Action", "year": 2021, "streaming_service": "Netflix"},
        {"title": "Don't Look Up", "genre": "Comedy", "year": 2021, "streaming_service": "Netflix"},
        {"title": "The Adam Project", "genre": "Sci-Fi", "year": 2022, "streaming_service": "Netflix"},
        {"title": "Enola Holmes 2", "genre": "Mystery", "year": 2022, "streaming_service": "Netflix"},
        {"title": "Glass Onion: A Knives Out Mystery", "genre": "Mystery", "year": 2022, "streaming_service": "Netflix"},
        {"title": "The Super Mario Bros. Movie", "genre": "Animation", "year": 2023, "streaming_service": "Netflix"},
        {"title": "Spider-Man: No Way Home", "genre": "Action", "year": 2021, "streaming_service": "Netflix"},
        {"title": "65", "genre": "Sci-Fi", "year": 2023, "streaming_service": "Netflix"},
        {"title": "No Hard Feelings", "genre": "Comedy", "year": 2023, "streaming_service": "Netflix"},
        {"title": "The Equalizer 3", "genre": "Action", "year": 2023, "streaming_service": "Netflix"},
        {"title": "Anyone But You", "genre": "Romance", "year": 2023, "streaming_service": "Netflix"},
        
        # Amazon Prime (Really streaming on Amazon)
        {"title": "The Tomorrow War", "genre": "Sci-Fi", "year": 2021, "streaming_service": "Amazon Prime"},
        {"title": "Coming 2 America", "genre": "Comedy", "year": 2021, "streaming_service": "Amazon Prime"},
        {"title": "The Boys in the Boat", "genre": "Drama", "year": 2023, "streaming_service": "Amazon Prime"},
        {"title": "Top Gun: Maverick", "genre": "Action", "year": 2022, "streaming_service": "Amazon Prime"},
        {"title": "Creed III", "genre": "Drama", "year": 2023, "streaming_service": "Amazon Prime"},
        {"title": "M3GAN", "genre": "Horror", "year": 2022, "streaming_service": "Amazon Prime"},
        {"title": "Fast X", "genre": "Action", "year": 2023, "streaming_service": "Amazon Prime"},
        {"title": "Talk to Me", "genre": "Horror", "year": 2022, "streaming_service": "Amazon Prime"},
        {"title": "The Beekeeper", "genre": "Action", "year": 2024, "streaming_service": "Amazon Prime"},
        
        # Disney+ (Really streaming on Disney+)
        {"title": "Black Panther: Wakanda Forever", "genre": "Action", "year": 2022, "streaming_service": "Disney+"},
        {"title": "Avatar: The Way of Water", "genre": "Sci-Fi", "year": 2022, "streaming_service": "Disney+"},
        {"title": "Guardians of the Galaxy Vol. 3", "genre": "Action", "year": 2023, "streaming_service": "Disney+"},
        {"title": "The Little Mermaid", "genre": "Adventure", "year": 2023, "streaming_service": "Disney+"},
        {"title": "Ant-Man and the Wasp: Quantumania", "genre": "Action", "year": 2023, "streaming_service": "Disney+"},
        {"title": "Elemental", "genre": "Animation", "year": 2023, "streaming_service": "Disney+"},
        {"title": "Wish", "genre": "Animation", "year": 2023, "streaming_service": "Disney+"},
        
        # HBO Max (Really streaming on HBO Max)
        {"title": "Dune", "genre": "Sci-Fi", "year": 2021, "streaming_service": "HBO Max"},
        {"title": "The Batman", "genre": "Action", "year": 2022, "streaming_service": "HBO Max"},
        {"title": "Elvis", "genre": "Drama", "year": 2022, "streaming_service": "HBO Max"},
        {"title": "Black Adam", "genre": "Action", "year": 2022, "streaming_service": "HBO Max"},
        {"title": "Shazam! Fury of the Gods", "genre": "Action", "year": 2023, "streaming_service": "HBO Max"},
        {"title": "Evil Dead Rise", "genre": "Horror", "year": 2023, "streaming_service": "HBO Max"},
        {"title": "The Flash", "genre": "Action", "year": 2023, "streaming_service": "HBO Max"},
        {"title": "Blue Beetle", "genre": "Action", "year": 2023, "streaming_service": "HBO Max"},
        {"title": "The Nun II", "genre": "Horror", "year": 2023, "streaming_service": "HBO Max"},
        {"title": "Ferrari", "genre": "Drama", "year": 2023, "streaming_service": "HBO Max"},
        {"title": "The Color Purple", "genre": "Musical", "year": 2023, "streaming_service": "HBO Max"},
        {"title": "Aquaman and the Lost Kingdom", "genre": "Action", "year": 2023, "streaming_service": "HBO Max"},
        
        # Crunchyroll Anime
        {"title": "Demon Slayer: Kimetsu no Yaiba", "genre": "Anime", "year": 2019, "streaming_service": "Crunchyroll"},
        {"title": "Jujutsu Kaisen", "genre": "Anime", "year": 2020, "streaming_service": "Crunchyroll"},
        {"title": "Attack on Titan", "genre": "Anime", "year": 2013, "streaming_service": "Crunchyroll"},
        {"title": "My Hero Academia", "genre": "Anime", "year": 2016, "streaming_service": "Crunchyroll"},
        {"title": "One Piece", "genre": "Anime", "year": 1999, "streaming_service": "Crunchyroll"},
        {"title": "Chainsaw Man", "genre": "Anime", "year": 2022, "streaming_service": "Crunchyroll"},
        {"title": "Spy x Family", "genre": "Anime", "year": 2022, "streaming_service": "Crunchyroll"},
        {"title": "Hunter x Hunter", "genre": "Anime", "year": 2011, "streaming_service": "Crunchyroll"},
        {"title": "Naruto: Shippuden", "genre": "Anime", "year": 2007, "streaming_service": "Crunchyroll"},
        {"title": "Death Note", "genre": "Anime", "year": 2006, "streaming_service": "Crunchyroll"},
        
        # Current Theater Releases (2023-2024) - Really in theaters
        {"title": "Oppenheimer", "genre": "Drama", "year": 2023, "in_theaters": True},
        {"title": "Barbie", "genre": "Comedy", "year": 2023, "in_theaters": True},
        {"title": "Killers of the Flower Moon", "genre": "Drama", "year": 2023, "in_theaters": True},
        {"title": "The Marvels", "genre": "Action", "year": 2023, "in_theaters": True},
        {"title": "Wonka", "genre": "Adventure", "year": 2023, "in_theaters": True},
        {"title": "Aquaman and the Lost Kingdom", "genre": "Action", "year": 2023, "in_theaters": True},
        {"title": "Migration", "genre": "Animation", "year": 2023, "in_theaters": True},
        {"title": "Anyone But You", "genre": "Romance", "year": 2023, "in_theaters": True},
        {"title": "The Beekeeper", "genre": "Action", "year": 2024, "in_theaters": True},
        {"title": "Mean Girls", "genre": "Musical", "year": 2024, "in_theaters": True},
        {"title": "Argylle", "genre": "Action", "year": 2024, "in_theaters": True},
        {"title": "Lisa Frankenstein", "genre": "Comedy", "year": 2024, "in_theaters": True},
        {"title": "Bob Marley: One Love", "genre": "Biography", "year": 2024, "in_theaters": True},
        {"title": "Dune: Part Two", "genre": "Sci-Fi", "year": 2024, "in_theaters": True},
        {"title": "Ghostbusters: Frozen Empire", "genre": "Comedy", "year": 2024, "in_theaters": True},
        
        # Anime Movies
        {"title": "Demon Slayer: Kimetsu no Yaiba - To the Hashira Training", "genre": "Anime", "year": 2024, "in_theaters": True},
        {"title": "The Boy and the Heron", "genre": "Anime", "year": 2023, "streaming_service": "HBO Max"},
        {"title": "Suzume", "genre": "Anime", "year": 2022, "streaming_service": "Crunchyroll"},
        {"title": "Jujutsu Kaisen 0", "genre": "Anime", "year": 2021, "streaming_service": "Crunchyroll"},
        
        # Other Streaming Services
        {"title": "John Wick: Chapter 4", "genre": "Action", "year": 2023, "streaming_service": "Starz"},
        {"title": "Scream VI", "genre": "Horror", "year": 2023, "streaming_service": "Paramount+"},
        {"title": "Transformers: Rise of the Beasts", "genre": "Action", "year": 2023, "streaming_service": "Paramount+"},
        {"title": "Mission: Impossible - Dead Reckoning Part One", "genre": "Action", "year": 2023, "streaming_service": "Paramount+"},
        {"title": "Cocaine Bear", "genre": "Comedy", "year": 2023, "streaming_service": "Peacock"},
        {"title": "Five Nights at Freddy's", "genre": "Horror", "year": 2023, "streaming_service": "Peacock"},
        {"title": "The Hunger Games: The Ballad of Songbirds & Snakes", "genre": "Drama", "year": 2023, "streaming_service": "Starz"},
        {"title": "Napoleon", "genre": "Drama", "year": 2023, "streaming_service": "Apple TV+"},
        {"title": "Argylle", "genre": "Action", "year": 2024, "streaming_service": "Apple TV+"},
        {"title": "Mean Girls", "genre": "Musical", "year": 2024, "streaming_service": "Paramount+"},
        
        # Classic Movies
        {"title": "The Dark Knight", "genre": "Action", "year": 2008},
        {"title": "Inception", "genre": "Action", "year": 2010},
        {"title": "The Shawshank Redemption", "genre": "Drama", "year": 1994},
        {"title": "Pulp Fiction", "genre": "Crime", "year": 1994},
        {"title": "Forrest Gump", "genre": "Drama", "year": 1994},
        {"title": "The Godfather", "genre": "Crime", "year": 1972},
        {"title": "The Matrix", "genre": "Sci-Fi", "year": 1999},
        {"title": "Interstellar", "genre": "Sci-Fi", "year": 2014},
    ]
    
    return enhanced_db

MOVIE_DATABASE = get_enhanced_movie_database()


# -----------------------------
# Enhanced AI Chat System
# -----------------------------
class AdvancedAIChat:
    def __init__(self):
        self.conversation_history = []
        self.omdb = RateLimitedOMDbAPI()
        self.user_preferences = {
            "favorite_genres": [],
            "watch_habits": {},
            "recent_interests": []
        }
        self.streaming_finder = EnhancedStreamingServiceFinder()
        
    def generate_ai_response(self, user_input, movie_data):
        """Generate intelligent AI response with streaming integration"""
        user_input_lower = user_input.lower()
        
        # Update user preferences based on conversation
        self._update_user_preferences(user_input, movie_data)
        
        # Enhanced response system with streaming integration
        if any(word in user_input_lower for word in ['watch', 'stream', 'where to watch', 'netflix', 'amazon', 'hulu', 'disney', 'youtube']):
            return self._get_streaming_response(user_input, movie_data)
        
        elif any(word in user_input_lower for word in ['ticket', 'theater', 'cinema', 'buy ticket']):
            return self._get_ticketing_response(user_input, movie_data)
        
        elif any(word in user_input_lower for word in ['anime', 'crunchyroll']):
            return self._get_anime_response(user_input, movie_data)
        
        elif any(word in user_input_lower for word in ['hello', 'hi', 'hey', 'greetings']):
            return self._get_greeting_response(movie_data)
        
        elif any(word in user_input_lower for word in ['recommend', 'suggest', 'what should i watch', 'what to watch']):
            return self._get_recommendation_response(user_input, movie_data)
        
        elif any(word in user_input_lower for word in ['action', 'comedy', 'drama', 'sci-fi', 'romance', 'horror', 'thriller']):
            return self._get_genre_response(user_input_lower, movie_data)
        
        elif any(word in user_input_lower for word in ['details', 'info', 'about movie', 'tell me about']):
            return self._get_movie_details_response(user_input)
        
        elif any(word in user_input_lower for word in ['search', 'find movie', 'look for']):
            return self._get_movie_search_response(user_input)
        
        elif any(word in user_input_lower for word in ['analyze', 'stats', 'statistics', 'my collection', 'how many']):
            return self._get_analysis_response(movie_data)
        
        elif any(word in user_input_lower for word in ['watched', 'unwatched', 'watchlist']):
            return self._get_watch_status_response(movie_data)
        
        elif any(word in user_input_lower for word in ['help', 'what can you do', 'features']):
            return self._get_help_response()
        
        elif any(word in user_input_lower for word in ['best', 'top', 'greatest']):
            return self._get_best_movies_response(user_input_lower)
        
        else:
            return self._get_intelligent_fallback(user_input, movie_data)
    
    def _get_streaming_response(self, user_input, movie_data):
        """Handle streaming-related queries"""
        words = user_input.split()
        movie_keywords = [word for word in words if word.lower() not in 
                         ['watch', 'stream', 'where', 'to', 'on', 'netflix', 'amazon', 'prime', 'disney', 'hulu', 'hbo', 'youtube', 'crunchyroll']]
        
        if movie_keywords:
            movie_title = " ".join(movie_keywords[:4])
            
            # Check if movie is in collection
            collection_movie = None
            if movie_data:
                for movie in movie_data:
                    if movie_title.lower() in movie[1].lower():
                        collection_movie = movie
                        break
            
            if collection_movie:
                title = collection_movie[1]
                year = collection_movie[3]
                genre = collection_movie[2]
                
                watch_options = self.streaming_finder.get_watch_options(title, year, genre)
                available_streaming = [s for s in watch_options['streaming'].values() if s['available']]
                
                response = f"🎬 **{title}** ({year})\n\n"
                
                if available_streaming:
                    response += "**Available on:**\n"
                    for service in available_streaming:
                        response += f"• {service['icon']} **{service['name']}** - [Watch Now]({service['url']})\n"
                else:
                    response += "**Streaming:** Not currently available on major platforms\n"
                
                if watch_options['in_theaters']:
                    response += "\n**🎟️ In Theaters Now!**\n"
                    response += "Get tickets from:\n"
                    for service in watch_options['ticketing'].values():
                        response += f"• {service['icon']} **{service['name']}** - [Buy Tickets]({service['url']})\n"
                
                # Check for anime
                if 'anime' in watch_options:
                    response += "\n**🍥 Anime Streaming:**\n"
                    for service in watch_options['anime'].values():
                        response += f"• {service['icon']} **{service['name']}** - [Watch Anime]({service['url']})\n"
                
                response += f"\n💡 *Click the 'Watch Now' button on the movie card for more options!*"
                return response
            else:
                return f"🎬 I couldn't find '{movie_title}' in your collection. Try searching for it in the AI Finder or add it to your collection first!"
        
        return "🎬 Tell me which movie you'd like to watch! For example: 'Where can I watch Inception?' or 'Is The Dark Knight on Netflix?'"

    def _get_ticketing_response(self, user_input, movie_data):
        """Handle ticketing-related queries"""
        current_year = datetime.now().year
        in_theaters_movies = [movie for movie in movie_data if len(movie) > 3 and movie[3] >= current_year - 1]
        
        if not in_theaters_movies:
            return "🎟️ No recent movies found in your collection that might be in theaters. Recent releases from 2023-2024 are most likely to be in theaters!"
        
        response = "🎟️ **Movies That Might Be In Theaters**\n\n"
        response += "These recent movies from your collection might be in theaters:\n\n"
        
        for movie in in_theaters_movies[:5]:  # Show top 5
            title = movie[1]
            year = movie[3]
            response += f"• **{title}** ({year})\n"
            response += f"  [Get Tickets](https://www.fandango.com/search?q={quote(title)})\n\n"
        
        response += "💡 *Click 'Watch Now' on any movie card to check all ticketing options!*"
        return response

    def _get_anime_response(self, user_input, movie_data):
        """Handle anime-related queries"""
        anime_integration = AnimeIntegration()
        
        words = user_input.split()
        anime_keywords = [word for word in words if word.lower() not in ['anime', 'watch', 'find', 'search']]
        
        if anime_keywords:
            anime_query = " ".join(anime_keywords)
            anime_results = anime_integration.search_anime(anime_query)
            
            if anime_results:
                response = f"🍥 **Anime Results for '{anime_query}'**\n\n"
                for anime in anime_results[:3]:
                    response += f"• **{anime['title']}** ({anime['year']}) - {anime['genre']}\n"
                    response += f"  [Watch on Crunchyroll]({anime['url']})\n\n"
                response += "💡 *Visit the AI Finder for more anime content!*"
                return response
            else:
                return f"🍥 No anime found for '{anime_query}'. Try popular anime like 'Demon Slayer', 'Jujutsu Kaisen', or 'Attack on Titan'."
        
        return "🍥 I can help you find anime! Try asking: 'Find anime Demon Slayer' or 'Search for Jujutsu Kaisen anime'"

    def _get_greeting_response(self, movie_data):
        """Personalized greeting based on user's collection"""
        total_movies = len(movie_data) if movie_data else 0
        watched_count = sum(1 for movie in movie_data if len(movie) > 4 and movie[4] == 1) if movie_data else 0
        
        greetings = [
            f"🎬 Welcome back, cinephile! I see you have {total_movies} movies in your collection ({watched_count} watched). I can help you search for movies, get details, and recommend films!",
            f"🌟 Hello there! With {total_movies} movies in your collection, we've got quite the film festival ahead! I can search for any movie you're curious about.",
            f"👋 Hey movie lover! Your collection of {total_movies} films is impressive! I can fetch detailed info or help you discover new movies.",
            f"🎭 Greetings, film enthusiast! {total_movies} movies and counting. I'm here with movie database integration to provide detailed information and recommendations!"
        ]
        
        return random.choice(greetings)

    def _get_recommendation_response(self, user_input, movie_data):
        """Intelligent movie recommendations"""
        if not movie_data:
            return "🎬 I'd love to recommend some movies! First, let's build your collection. You can also ask me to search for any movie, or try adding a few movies you enjoy!"
        
        # Get popular movies from enhanced database
        popular_movies = [m for m in MOVIE_DATABASE if m.get('streaming_service') or m.get('in_theaters')][:6]
        
        response = "🎯 **Popular Movies You Might Like**\n\n"
        
        for i, movie in enumerate(popular_movies, 1):
            streaming_info = ""
            if movie.get('streaming_service'):
                streaming_info = f" - 📺 {movie['streaming_service']}"
            elif movie.get('in_theaters'):
                streaming_info = " - 🎟️ In Theaters"
            
            response += f"{i}. **{movie['title']}** ({movie['year']}) - {movie['genre']}{streaming_info}\n"
        
        response += "\n🔍 *Use the AI Finder to search for these movies and add them to your collection!*"
        return response

    def _get_movie_details_response(self, user_input):
        """Get movie details from OMDB API based on user query"""
        words = user_input.split()
        movie_keywords = [word for word in words if word.lower() not in ['details', 'info', 'about', 'movie', 'get', 'tell', 'me']]
        
        if movie_keywords:
            movie_title = " ".join(movie_keywords[:4])
            
            with st.spinner(f"🔍 Searching for '{movie_title}'..."):
                movie_data = self.omdb.get_movie_details(movie_title)
            
            if movie_data:
                response = f"🎬 **{movie_data.get('Title', 'Movie')}** ({movie_data.get('Year', 'N/A')})\n\n"
                response += f"**Director:** {movie_data.get('Director', 'N/A')}\n"
                response += f"**Genre:** {movie_data.get('Genre', 'N/A')}\n"
                response += f"**Runtime:** {movie_data.get('Runtime', 'N/A')}\n"
                
                # Display ratings
                ratings = movie_data.get('Ratings', [])
                imdb_rating = movie_data.get('imdbRating', 'N/A')
                
                if imdb_rating != 'N/A':
                    response += f"**IMDB Rating:** {imdb_rating}/10\n"
                
                for rating in ratings:
                    source = rating.get('Source', '')
                    value = rating.get('Value', '')
                    if 'Rotten Tomatoes' in source:
                        response += f"**Rotten Tomatoes:** {value}\n"
                    elif 'Metacritic' in source:
                        response += f"**Metacritic:** {value}\n"
                
                response += f"**Plot:** {movie_data.get('Plot', 'N/A')}\n\n"
                
                response += f"💡 *Want to add this to your collection? Use the AI Finder feature!*"
                return response
            else:
                return f"❌ I couldn't find detailed information for '{movie_title}'. Try using the AI Finder feature for better results!"
        
        return "🎬 Please specify which movie you'd like details about! For example: 'Get details about Inception' or 'Tell me about The Dark Knight'"

    def _get_movie_search_response(self, user_input):
        """Handle movie search requests"""
        return "🔍 I'd be happy to help you search for movies! Use the AI Finder section to explore the database and find new movies to add to your collection."

    def _get_analysis_response(self, movie_data):
        """Analyze user's movie preferences and provide insights"""
        if not movie_data:
            return "📊 I'd love to analyze your movie taste! Start by adding some films to your collection, or use the AI Finder to discover and add new movies!"
        
        stats = get_stats()
        
        analysis = f"🎯 **Your Cinema Profile**\n\n"
        analysis += f"• **Collection Size**: {stats['total_movies']} films\n"
        analysis += f"• **Completion Rate**: {stats['watched_count']}/{stats['total_movies']} watched ({stats['completion_rate']:.1f}%)\n"
        analysis += f"• **In Theaters**: {stats['in_theaters_count']} movies\n"
        analysis += f"• **Average Rating**: {stats['average_rating']:.1f} ⭐\n"
        
        analysis += "\n🌟 **Recommendation**: Explore the AI Finder to discover more movies!"
        
        return analysis

    def _get_watch_status_response(self, movie_data):
        """Provide information about watched and unwatched movies"""
        if not movie_data:
            return "📝 Your collection is empty. Add some movies using the AI Finder feature to start tracking your watch progress!"
        
        watched_movies = [movie for movie in movie_data if len(movie) > 4 and movie[4] == 1]
        unwatched_movies = [movie for movie in movie_data if len(movie) > 4 and movie[4] == 0]
        
        response = f"📊 **Watch Status Overview**\n\n"
        response += f"• **Watched**: {len(watched_movies)} movies\n"
        response += f"• **Unwatched**: {len(unwatched_movies)} movies\n"
        response += f"• **Completion Rate**: {len(watched_movies)/len(movie_data)*100:.1f}%\n\n"
        
        if unwatched_movies:
            response += "🎬 **Top Unwatched Movies**:\n"
            for movie in unwatched_movies[:3]:
                response += f"• {movie[1]} ({movie[3]}) - {movie[2]}\n"
        
        response += f"\n🔍 *Find more movies to watch using AI Finder!*"
        
        return response

    def _get_help_response(self):
        """Comprehensive help guide"""
        return """
🤖 **Movie Assistant with Enhanced Features**

Here's what I can help you with:

🔍 **AI Finder Movie Search & Details**
• "Search for Inception on AI Finder"
• "Get details about The Dark Knight"
• "Find information about Parasite"

🎯 **Streaming & Watching**
• "Where can I watch Oppenheimer?"
• "Is Barbie on Netflix?"
• "Get tickets for Dune 2"

🍥 **Anime Content**
• "Find anime Demon Slayer"
• "Search for Jujutsu Kaisen"
• "Watch Attack on Titan on Crunchyroll"

📊 **Collection Management**
• "Analyze my movie taste"
• "What haven't I watched?"
• "My watchlist status"

🎬 **Recommendations**
• "Recommend action movies"
• "What should I watch tonight?"
• "Popular movies on Netflix"

💡 **Pro Tips**: 
• Use AI Finder to discover new movies
• Click "Watch Now" for streaming options
• Search for anime in AI Finder

What would you like to explore today?
        """

    def _get_best_movies_response(self, user_input):
        """Recommend best movies based on categories"""
        best_movies = {
            'all_time': [
                "The Godfather (1972) - Crime epic masterpiece",
                "The Shawshank Redemption (1994) - Ultimate story of hope",
                "The Dark Knight (2008) - Superhero cinema perfected",
                "Parasite (2019) - Brilliant social thriller",
                "Pulp Fiction (1994) - Revolutionary storytelling"
            ],
            'recent': [
                "Oppenheimer (2023) - Historical drama masterpiece",
                "Spider-Man: Across the Spider-Verse (2023) - Animation revolution",
                "Dune (2021) - Epic sci-fi spectacle",
                "Everything Everywhere All At Once (2022) - Multiverse madness",
                "The Batman (2022) - Dark detective thriller"
            ]
        }
        
        if 'recent' in user_input or 'new' in user_input:
            category = 'recent'
            title = "🎬 Best Recent Movies (2020s)"
        else:
            category = 'all_time'
            title = "🏆 All-Time Greatest Movies"
        
        response = f"{title}\n\n"
        for i, movie in enumerate(best_movies[category], 1):
            response += f"{i}. {movie}\n"
        
        response += f"\n🔍 *Search AI Finder for any of these movies to get detailed information!*"
        
        return response

    def _get_intelligent_fallback(self, user_input, movie_data):
        """Intelligent fallback for unexpected queries"""
        fallbacks = [
            f"🎬 That's an interesting question! I can help you search AI Finder for movies, get detailed information, or manage your collection. What would you like to know?",
            f"🤔 I'm not sure I understand completely. I'm here to help with movie searches, recommendations, and collection management using movie database data.",
            f"🔍 I specialize in movie information from databases and collection management. Try asking me to search for a movie, get details, or recommend something to watch!",
            f"🌟 Great question! I can fetch movie details from databases, help you discover new films, or analyze your collection. What movie-related topic can I assist with?"
        ]
        
        return random.choice(fallbacks)

    def _update_user_preferences(self, user_input, movie_data):
        """Learn from user interactions"""
        # Basic preference tracking
        genre_keywords = {
            'action': ['action', 'fight', 'adventure', 'thriller', 'exciting'],
            'comedy': ['comedy', 'funny', 'laugh', 'humor', 'hilarious'],
            'drama': ['drama', 'emotional', 'serious', 'story', 'deep'],
            'sci-fi': ['sci-fi', 'science fiction', 'future', 'space', 'alien'],
            'romance': ['romance', 'love', 'relationship', 'romantic', 'couple'],
            'anime': ['anime', 'manga', 'japanese animation']
        }
        
        for genre, keywords in genre_keywords.items():
            if any(keyword in user_input.lower() for keyword in keywords):
                if genre not in self.user_preferences["favorite_genres"]:
                    self.user_preferences["favorite_genres"].append(genre)

# -----------------------------
# Enhanced Analytics Functions with Advanced Visualizations
# -----------------------------
def create_advanced_analytics_charts(movie_data):
    """Optimized chart creation with error handling"""
    if not movie_data:
        return tuple([None] * 6)
    
    # Convert to DataFrame once
    try:
        df = pd.DataFrame([
            {
                "title": m[1], "genre": m[2], "year": m[3],
                "watched": m[4] == 1, "rating": m[5] if len(m) > 5 else 0,
                "added_at": m[16] if len(m) > 16 and m[16] and not m[16].startswith('tt') 
                           else datetime.now().strftime('%Y-%m-%d')
            }
            for m in movie_data if len(m) >= 4
        ])
    except Exception as e:
        logging.error(f"DataFrame creation error: {e}")
        return tuple([None] * 6)
    
    if df.empty:
        return tuple([None] * 6)
    
    # Reusable chart config
    chart_config = {
        'paper_bgcolor': 'rgba(0,0,0,0)',
        'plot_bgcolor': 'rgba(0,0,0,0)',
        'font_color': 'white',
        'title_font_size': 20,
        'title_x': 0.5
    }
    
    charts = []
    
    # 1. Genre Distribution
    try:
        genre_counts = df['genre'].value_counts()
        fig = px.pie(values=genre_counts.values, names=genre_counts.index, 
                     title="🎭 Genre Distribution", hole=0.5)
        fig.update_layout(**chart_config)
        charts.append(fig)
    except Exception:
        charts.append(None)
    
    # 2. Watch Status
    try:
        watch_counts = df['watched'].value_counts()
        fig = px.bar(x=['Watched', 'Unwatched'], 
                     y=[watch_counts.get(True, 0), watch_counts.get(False, 0)], 
                     title="✅ Watch Status Overview",
                     color=['Watched', 'Unwatched'],
                     color_discrete_map={'Watched': '#6BCF7F', 'Unwatched': '#FF6B6B'})
        fig.update_layout(**chart_config)
        fig.update_traces(marker_line_color='white', marker_line_width=1.5)
        charts.append(fig)
    except Exception:
        charts.append(None)
    
    # 3. Year Distribution
    try:
        if 'year' in df.columns and df['year'].notna().any():
            year_counts = df['year'].value_counts().sort_index()
            # Filter out any non-numeric years
            year_counts = year_counts[year_counts.index.astype(str).str.isdigit()]
            if not year_counts.empty:
                fig = px.area(x=year_counts.index, y=year_counts.values, 
                              title="📅 Movie Collection Timeline",
                              color_discrete_sequence=['#FFD93D'])
                fig.update_layout(
                    paper_bgcolor='rgba(0,0,0,0)',
                    plot_bgcolor='rgba(0,0,0,0)',
                    font_color='white',
                    xaxis_title="Release Year",
                    yaxis_title="Number of Movies",
                    title_font_size=20,
                    title_x=0.5
                )
                fig.update_traces(fillgradient=dict(
                    type="vertical",
                    colorscale=[[0, 'rgba(255,217,61,0.3)'], [1, 'rgba(255,217,61,0.8)']]
                ))
                charts.append(fig)
            else:
                charts.append(None)
        else:
            charts.append(None)
    except Exception:
        charts.append(None)
    
    # 4. Rating Distribution
    try:
        if 'rating' in df.columns and df['rating'].notna().any():
            rating_dist = df[df['rating'] > 0]['rating'].value_counts().sort_index()
            if not rating_dist.empty and len(rating_dist) > 1:
                fig = px.line_polar(r=rating_dist.values, theta=rating_dist.index, 
                                   title="⭐ User Ratings Distribution", line_close=True,
                                   color_discrete_sequence=['#FF6B6B'])
                fig.update_traces(fill='toself')
                fig.update_layout(
                    paper_bgcolor='rgba(0,0,0,0)',
                    font_color='white',
                    polar=dict(
                        bgcolor='rgba(0,0,0,0)',
                        radialaxis=dict(visible=True, color='white'),
                        angularaxis=dict(color='white')
                    ),
                    title_font_size=20,
                    title_x=0.5
                )
                charts.append(fig)
            else:
                charts.append(None)
        else:
            charts.append(None)
    except Exception:
        charts.append(None)
    
    # 5. Monthly Activity
    try:
        if 'added_at' in df.columns and df['added_at'].notna().any():
            # Safely convert to datetime
            valid_dates = []
            for date_str in df['added_at']:
                try:
                    if date_str and isinstance(date_str, str) and not date_str.startswith('tt'):
                        parsed_date = pd.to_datetime(date_str, errors='coerce')
                        if pd.notna(parsed_date):
                            valid_dates.append(parsed_date)
                        else:
                            valid_dates.append(pd.Timestamp.now())
                    else:
                        valid_dates.append(pd.Timestamp.now())
                except Exception:
                    valid_dates.append(pd.Timestamp.now())
            
            if valid_dates:
                temp_dates = pd.Series(valid_dates)
                monthly_activity = temp_dates.groupby(temp_dates.dt.to_period('M')).size()
                monthly_activity.index = monthly_activity.index.astype(str)
                
                if not monthly_activity.empty:
                    fig = px.bar(x=monthly_activity.index, y=monthly_activity.values,
                                 title="📈 Monthly Collection Growth",
                                 color_discrete_sequence=['#4D96FF'])
                    fig.update_layout(
                        paper_bgcolor='rgba(0,0,0,0)',
                        plot_bgcolor='rgba(0,0,0,0)',
                        font_color='white',
                        xaxis_title="Month",
                        yaxis_title="Movies Added",
                        title_font_size=20,
                        title_x=0.5
                    )
                    charts.append(fig)
                else:
                    charts.append(None)
            else:
                charts.append(None)
        else:
            charts.append(None)
    except Exception as e:
        print(f"Error creating monthly activity chart: {e}")
        charts.append(None)
    
    # 6. Genre vs Watch Status
    try:
        if not df.empty and 'genre' in df.columns and 'watched' in df.columns:
            genre_watch = pd.crosstab(df['genre'], df['watched'])
            if 'Unwatched' not in genre_watch.columns:
                genre_watch['Unwatched'] = 0
            if 'Watched' not in genre_watch.columns:
                genre_watch['Watched'] = 0
                
            genre_watch.columns = ['Unwatched', 'Watched']
            
            if not genre_watch.empty:
                fig = px.bar(genre_watch, x=genre_watch.index, y=['Watched', 'Unwatched'],
                             title="🎯 Genre Completion Analysis",
                             color_discrete_map={'Watched': '#6BCF7F', 'Unwatched': '#FF6B6B'})
                fig.update_layout(
                    paper_bgcolor='rgba(0,0,0,0)',
                    plot_bgcolor='rgba(0,0,0,0)',
                    font_color='white',
                    xaxis_title="Genre",
                    yaxis_title="Number of Movies",
                    title_font_size=20,
                    title_x=0.5,
                    barmode='stack'
                )
                charts.append(fig)
            else:
                charts.append(None)
        else:
            charts.append(None)
    except Exception:
        charts.append(None)
    
    return tuple(charts)
# -----------------------------
# Helper Functions
# -----------------------------
def add_sample_movies(count=5):
    """Add sample movies to the collection"""
    added_count = 0
    existing_movies = get_movies_safe()
    existing_titles = [movie[1].lower() for movie in existing_movies] if existing_movies else []
    
    available_movies = [movie for movie in MOVIE_DATABASE 
                       if movie["title"].lower() not in existing_titles]
    
    if not available_movies:
        return 0
    
    movies_to_add = random.sample(available_movies, min(count, len(available_movies)))
    
    for movie in movies_to_add:
        try:
            add_movie(title=movie["title"], genre=movie["genre"], year=movie["year"], watched=random.choice([True, False]))
            added_count += 1
        except Exception as e:
            logging.error(f"Error adding sample movie {movie['title']}: {e}")
            continue
    
    return added_count
# -----------------------------
# Input Validation and Error Handling
# -----------------------------
def sanitize_input(text):
    """Basic input sanitization"""
    if not text:
        return ""
    return html.escape(text.strip())

def validate_movie_data(title, genre, year):
    """Validate movie data before adding to database"""
    errors = []
    
    if not title or len(title.strip()) == 0:
        errors.append("Movie title is required")
    
    if not genre or len(genre.strip()) == 0:
        errors.append("Genre is required")
    
    current_year = datetime.now().year
    if year < 1900 or year > current_year + 5:
        errors.append(f"Year must be between 1900 and {current_year + 5}")
    
    return errors

# -----------------------------
# ColorBends Background Animation Component
# -----------------------------
def inject_color_bends_background():
    """Inject the ColorBends animated background"""
    st.markdown("""
    <style>
    /* ColorBends Background Container */
    .color-bends-background {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -9999;
        pointer-events: none;
        opacity: 0.7;
    }
    
    /* Ensure main content is above background */
    .main .block-container {
        position: relative;
        z-index: 1;
        background: rgba(12, 12, 12, 0.85);
        border-radius: 15px;
        margin: 1rem;
        padding: 2rem;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    /* Sidebar styling */
    .css-1d391kg, .css-1lcbmhc {
        background: rgba(12, 12, 12, 0.9) !important;
        backdrop-filter: blur(10px);
        border-right: 1px solid rgba(255, 255, 255, 0.1) !important;
    }
    </style>
    
    <div class="color-bends-background" id="colorBendsContainer"></div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script>
    class ColorBendsBackground {
        constructor() {
            this.container = document.getElementById('colorBendsContainer');
            this.scene = new THREE.Scene();
            this.camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
            this.renderer = new THREE.WebGLRenderer({ 
                antialias: false, 
                alpha: true,
                powerPreference: 'high-performance'
            });
            
            this.setupRenderer();
            this.createGeometry();
            this.setupShader();
            this.animate();
            this.handleResize();
            
            window.addEventListener('resize', () => this.handleResize());
        }
        
        setupRenderer() {
            this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
            this.renderer.setClearColor(0x000000, 0);
            this.renderer.domElement.style.width = '100%';
            this.renderer.domElement.style.height = '100%';
            this.renderer.domElement.style.display = 'block';
            this.container.appendChild(this.renderer.domElement);
        }
        
        createGeometry() {
            this.geometry = new THREE.PlaneGeometry(2, 2);
        }
        
        setupShader() {
            const MAX_COLORS = 8;
            
            const vertexShader = `
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    gl_Position = vec4(position, 1.0);
                }
            `;
            
            const fragmentShader = `
                #define MAX_COLORS ${MAX_COLORS}
                uniform vec2 uCanvas;
                uniform float uTime;
                uniform float uSpeed;
                uniform vec2 uRot;
                uniform int uColorCount;
                uniform vec3 uColors[MAX_COLORS];
                uniform int uTransparent;
                uniform float uScale;
                uniform float uFrequency;
                uniform float uWarpStrength;
                uniform vec2 uPointer;
                uniform float uMouseInfluence;
                uniform float uParallax;
                uniform float uNoise;
                varying vec2 vUv;

                void main() {
                    float t = uTime * uSpeed;
                    vec2 p = vUv * 2.0 - 1.0;
                    p += uPointer * uParallax * 0.1;
                    vec2 rp = vec2(p.x * uRot.x - p.y * uRot.y, p.x * uRot.y + p.y * uRot.x);
                    vec2 q = vec2(rp.x * (uCanvas.x / uCanvas.y), rp.y);
                    q /= max(uScale, 0.0001);
                    q /= 0.5 + 0.2 * dot(q, q);
                    q += 0.2 * cos(t) - 7.56;
                    vec2 toward = (uPointer - rp);
                    q += toward * uMouseInfluence * 0.2;

                    vec3 col = vec3(0.0);
                    float a = 1.0;

                    if (uColorCount > 0) {
                        vec2 s = q;
                        vec3 sumCol = vec3(0.0);
                        float cover = 0.0;
                        for (int i = 0; i < MAX_COLORS; ++i) {
                            if (i >= uColorCount) break;
                            s -= 0.01;
                            vec2 r = sin(1.5 * (s.yx * uFrequency) + 2.0 * cos(s * uFrequency));
                            float m0 = length(r + sin(5.0 * r.y * uFrequency - 3.0 * t + float(i)) / 4.0);
                            float kBelow = clamp(uWarpStrength, 0.0, 1.0);
                            float kMix = pow(kBelow, 0.3);
                            float gain = 1.0 + max(uWarpStrength - 1.0, 0.0);
                            vec2 disp = (r - s) * kBelow;
                            vec2 warped = s + disp * gain;
                            float m1 = length(warped + sin(5.0 * warped.y * uFrequency - 3.0 * t + float(i)) / 4.0);
                            float m = mix(m0, m1, kMix);
                            float w = 1.0 - exp(-6.0 / exp(6.0 * m));
                            sumCol += uColors[i] * w;
                            cover = max(cover, w);
                        }
                        col = clamp(sumCol, 0.0, 1.0);
                        a = uTransparent > 0 ? cover : 1.0;
                    } else {
                        vec2 s = q;
                        for (int k = 0; k < 3; ++k) {
                            s -= 0.01;
                            vec2 r = sin(1.5 * (s.yx * uFrequency) + 2.0 * cos(s * uFrequency));
                            float m0 = length(r + sin(5.0 * r.y * uFrequency - 3.0 * t + float(k)) / 4.0);
                            float kBelow = clamp(uWarpStrength, 0.0, 1.0);
                            float kMix = pow(kBelow, 0.3);
                            float gain = 1.0 + max(uWarpStrength - 1.0, 0.0);
                            vec2 disp = (r - s) * kBelow;
                            vec2 warped = s + disp * gain;
                            float m1 = length(warped + sin(5.0 * warped.y * uFrequency - 3.0 * t + float(k)) / 4.0);
                            float m = mix(m0, m1, kMix);
                            col[k] = 1.0 - exp(-6.0 / exp(6.0 * m));
                        }
                        a = uTransparent > 0 ? max(max(col.r, col.g), col.b) : 1.0;
                    }

                    if (uNoise > 0.0001) {
                        float n = fract(sin(dot(gl_FragCoord.xy + vec2(uTime), vec2(12.9898, 78.233))) * 43758.5453123);
                        col += (n - 0.5) * uNoise;
                        col = clamp(col, 0.0, 1.0);
                    }

                    vec3 rgb = (uTransparent > 0) ? col * a : col;
                    gl_FragColor = vec4(rgb, a * 0.3);
                }
            `;
            
            // Enhanced color palette for movie theme
            const colors = [
                new THREE.Vector3(1.0, 0.36, 0.48),  // #ff5c7a - Pink
                new THREE.Vector3(0.54, 0.36, 1.0),  // #8a5cff - Purple  
                new THREE.Vector3(0.0, 1.0, 0.82),   // #00ffd1 - Cyan
                new THREE.Vector3(1.0, 0.85, 0.24),  // #ffd93d - Yellow
                new THREE.Vector3(0.42, 0.81, 0.5),  // #6bcf7f - Green
                new THREE.Vector3(0.3, 0.59, 1.0)    // #4d96ff - Blue
            ];
            
            this.uColorsArray = Array.from({ length: MAX_COLORS }, (_, i) => 
                colors[i] || new THREE.Vector3(0, 0, 0)
            );
            
            this.uniforms = {
                uCanvas: { value: new THREE.Vector2(this.container.clientWidth, this.container.clientHeight) },
                uTime: { value: 0 },
                uSpeed: { value: 0.3 },
                uRot: { value: new THREE.Vector2(Math.cos(0.5), Math.sin(0.5)) },
                uColorCount: { value: colors.length },
                uColors: { value: this.uColorsArray },
                uTransparent: { value: 1 },
                uScale: { value: 1.2 },
                uFrequency: { value: 1.4 },
                uWarpStrength: { value: 1.2 },
                uPointer: { value: new THREE.Vector2(0, 0) },
                uMouseInfluence: { value: 0.8 },
                uParallax: { value: 0.6 },
                uNoise: { value: 0.08 }
            };
            
            this.material = new THREE.ShaderMaterial({
                vertexShader: vertexShader,
                fragmentShader: fragmentShader,
                uniforms: this.uniforms,
                transparent: true
            });
            
            this.mesh = new THREE.Mesh(this.geometry, this.material);
            this.scene.add(this.mesh);
            
            // Mouse interaction
            this.mouse = new THREE.Vector2(0, 0);
            this.targetMouse = new THREE.Vector2(0, 0);
            document.addEventListener('mousemove', (e) => {
                this.targetMouse.x = (e.clientX / window.innerWidth) * 2 - 1;
                this.targetMouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
            });
        }
        
        animate() {
            requestAnimationFrame(() => this.animate());
            
            this.uniforms.uTime.value += 0.016;
            
            // Smooth mouse follow
            this.mouse.lerp(this.targetMouse, 0.05);
            this.uniforms.uPointer.value.copy(this.mouse);
            
            // Auto rotation
            const time = this.uniforms.uTime.value * 0.1;
            const rotation = time * 0.3;
            this.uniforms.uRot.value.set(Math.cos(rotation), Math.sin(rotation));
            
            this.renderer.render(this.scene, this.camera);
        }
        
        handleResize() {
            const width = this.container.clientWidth;
            const height = this.container.clientHeight;
            
            this.renderer.setSize(width, height);
            this.uniforms.uCanvas.value.set(width, height);
        }
    }
    
    // Initialize when DOM is loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => new ColorBendsBackground());
    } else {
        new ColorBendsBackground();
    }
    </script>
    """, unsafe_allow_html=True)

# -----------------------------
# Ultra Advanced Custom CSS with Cinematic Animations
# -----------------------------
def inject_advanced_style():
    """Inject enhanced CSS with ColorBends integration"""
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Orbitron:wght@400;700;900&family=Poppins:wght@300;400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&display=swap');
    
    .stApp {
        background: transparent !important;
        color: #ffffff;
        font-family: 'Poppins', sans-serif;
        min-height: 100vh;
    }
    
    /* Main content area with glass effect */
    .main .block-container {
        background: rgba(12, 12, 12, 0.85) !important;
        backdrop-filter: blur(20px);
        border-radius: 20px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        margin: 1rem;
        padding: 2rem;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
    }
    
    /* Cinematic Floating Particles */
    .particles {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: -9998;
    }
    
    .particle {
        position: absolute;
        background: radial-gradient(circle, rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 70%);
        border-radius: 50%;
        animation: float 6s infinite linear;
    }
    
    @keyframes float {
        0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }
    }
    
    /* Ultra Animated CodeFlix Title */
    .cinematic-title {
        font-family: 'Orbitron', monospace;
        font-size: 5.5rem;
        font-weight: 900;
        text-align: center;
        background: linear-gradient(45deg, 
            #FF6B6B, #FFD93D, #6BCF7F, #4D96FF, 
            #9D4BFF, #FF6B6B, #FFD93D, #6BCF7F);
        background-size: 400% 400%;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        animation: rainbowGlow 8s ease infinite, cinematicPulse 3s ease-in-out infinite;
        text-shadow: 
            0 0 20px rgba(255, 107, 107, 0.3),
            0 0 40px rgba(255, 217, 61, 0.2),
            0 0 60px rgba(109, 207, 127, 0.1);
        margin: 0;
        padding: 1rem 0;
        position: relative;
        letter-spacing: 2px;
    }
    
    .cinematic-title::before {
        content: 'CODEFLIX';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(45deg, 
            transparent 45%, 
            rgba(255, 255, 255, 0.1) 50%, 
            transparent 55%);
        background-size: 200% 100%;
        animation: shimmer 4s infinite;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    @keyframes rainbowGlow {
        0%, 100% { background-position: 0% 50%; filter: hue-rotate(0deg); }
        50% { background-position: 100% 50%; filter: hue-rotate(180deg); }
    }
    
    @keyframes cinematicPulse {
        0%, 100% { transform: scale(1); text-shadow: 0 0 20px rgba(255, 107, 107, 0.3); }
        50% { transform: scale(1.02); text-shadow: 0 0 40px rgba(255, 217, 61, 0.4); }
    }
    
    @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }
    
    .cinematic-subtitle {
        font-family: 'Rajdhani', sans-serif;
        font-size: 1.8rem;
        text-align: center;
        background: linear-gradient(135deg, #FFD93D, #6BCF7F);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        animation: subtitleGlow 3s ease-in-out infinite alternate;
        margin: 0;
        padding-bottom: 3rem;
        font-weight: 600;
        letter-spacing: 1px;
    }
    
    @keyframes subtitleGlow {
        0% { text-shadow: 0 0 10px rgba(255, 217, 61, 0.3); }
        100% { text-shadow: 0 0 20px rgba(107, 207, 127, 0.5); }
    }
    
    .hero-container {
        background: linear-gradient(135deg, 
            rgba(12, 12, 12, 0.95) 0%, 
            rgba(26, 26, 46, 0.9) 50%, 
            rgba(15, 52, 96, 0.85) 100%);
        padding: 4rem 3rem;
        border-radius: 25px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        margin-bottom: 3rem;
        backdrop-filter: blur(20px);
        box-shadow: 
            0 20px 40px rgba(0, 0, 0, 0.5),
            0 0 100px rgba(77, 150, 255, 0.1);
        position: relative;
        overflow: hidden;
        animation: containerFloat 6s ease-in-out infinite;
    }
    
    @keyframes containerFloat {
        0%, 100% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
    }
    
    .hero-container::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: conic-gradient(
            from 0deg,
            transparent,
            rgba(255, 107, 107, 0.1),
            rgba(255, 217, 61, 0.1),
            rgba(107, 207, 127, 0.1),
            rgba(77, 150, 255, 0.1),
            transparent
        );
        animation: rotate 10s linear infinite;
        z-index: -1;
    }
    
    @keyframes rotate {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    /* Enhanced Glass Cards */
    .glass-card {
        background: rgba(20, 20, 35, 0.7);
        backdrop-filter: blur(25px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 20px;
        padding: 30px;
        margin: 20px 0;
        transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 
            0 15px 35px rgba(0, 0, 0, 0.4),
            inset 0 1px 0 rgba(255, 255, 255, 0.1);
        position: relative;
        overflow: hidden;
    }
    
    .glass-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(
            90deg,
            transparent,
            rgba(255, 255, 255, 0.1),
            transparent
        );
        transition: left 0.6s;
    }
    
    .glass-card:hover {
        transform: translateY(-8px) scale(1.02);
        border-color: rgba(255, 107, 107, 0.5);
        box-shadow: 
            0 25px 50px rgba(255, 107, 107, 0.2),
            0 0 80px rgba(255, 107, 107, 0.1);
    }
    
    .glass-card:hover::before {
        left: 100%;
    }
    
    /* Advanced Buttons */
    .advanced-btn {
        background: linear-gradient(135deg, #FF6B6B 0%, #FFD93D 50%, #6BCF7F 100%) !important;
        background-size: 200% 200% !important;
        color: #0c0c0c !important;
        border: none !important;
        border-radius: 15px !important;
        padding: 15px 30px !important;
        font-weight: 800 !important;
        font-size: 16px !important;
        font-family: 'Rajdhani', sans-serif !important;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
        box-shadow: 
            0 8px 25px rgba(255, 107, 107, 0.4),
            inset 0 1px 0 rgba(255, 255, 255, 0.3) !important;
        position: relative;
        overflow: hidden;
        letter-spacing: 1px;
    }
    
    .advanced-btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        transition: left 0.6s;
    }
    
    .advanced-btn:hover {
        transform: translateY(-3px) scale(1.05) !important;
        box-shadow: 
            0 15px 35px rgba(255, 107, 107, 0.6),
            0 0 40px rgba(255, 217, 61, 0.4) !important;
        background-position: 100% 100% !important;
    }
    
    .advanced-btn:hover::before {
        left: 100%;
    }
    
    /* Movie Cards with Holographic Effect */
    .movie-card {
        background: linear-gradient(135deg, 
            rgba(30, 30, 45, 0.9), 
            rgba(20, 20, 35, 0.9));
        border-radius: 20px;
        padding: 25px;
        margin: 20px 0;
        border: 1px solid rgba(255, 255, 255, 0.1);
        transition: all 0.4s ease;
        position: relative;
        overflow: hidden;
    }
    
    .movie-card::before {
        content: '';
        position: absolute;
        top: -2px;
        left: -2px;
        right: -2px;
        bottom: -2px;
        background: linear-gradient(45deg, 
            #FF6B6B, #FFD93D, #6BCF7F, #4D96FF, #9D4BFF);
        background-size: 400% 400%;
        z-index: -1;
        border-radius: 22px;
        animation: borderGlow 6s linear infinite;
        opacity: 0;
        transition: opacity 0.4s;
    }
    
    .movie-card:hover::before {
        opacity: 1;
    }
    
    .movie-card:hover {
        transform: translateY(-5px) scale(1.02);
        border-color: transparent;
        box-shadow: 
            0 20px 40px rgba(0, 0, 0, 0.4),
            0 0 60px rgba(255, 107, 107, 0.2);
    }
    
    @keyframes borderGlow {
        0%, 100% { background-position: 0% 50%; filter: hue-rotate(0deg); }
        50% { background-position: 100% 50%; filter: hue-rotate(180deg); }
    }
    
    /* Enhanced Headers */
    h1, h2, h3, h4, h5, h6 {
        font-family: 'Rajdhani', sans-serif !important;
        font-weight: 700 !important;
        background: linear-gradient(135deg, #FFFFFF, #FFD93D, #6BCF7F);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    }
    
    /* Movie Detail Cards */
    .movie-detail-card {
        background: linear-gradient(135deg, 
            rgba(25, 25, 40, 0.95), 
            rgba(15, 15, 30, 0.95));
        border-radius: 20px;
        padding: 30px;
        margin: 25px 0;
        border: 1px solid rgba(255, 107, 107, 0.3);
        box-shadow: 
            0 20px 40px rgba(0, 0, 0, 0.4),
            inset 0 1px 0 rgba(255, 255, 255, 0.1);
        position: relative;
        overflow: hidden;
    }
    
    .movie-detail-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, #FF6B6B, #FFD93D, #6BCF7F);
        background-size: 200% 100%;
        animation: loadingBar 3s ease-in-out infinite;
    }
    
    @keyframes loadingBar {
        0%, 100% { background-position: -200% 0; }
        50% { background-position: 200% 0; }
    }
    
    /* Rating Badges */
    .rating-badge {
        background: linear-gradient(135deg, #FFD93D, #FF6B6B);
        color: #0c0c0c !important;
        padding: 8px 16px;
        border-radius: 25px;
        font-weight: 800;
        font-size: 0.9em;
        font-family: 'Rajdhani', sans-serif;
        box-shadow: 0 4px 15px rgba(255, 217, 61, 0.3);
        animation: badgePulse 2s ease-in-out infinite;
    }
    
    @keyframes badgePulse {
        0%, 100% { transform: scale(1); box-shadow: 0 4px 15px rgba(255, 217, 61, 0.3); }
        50% { transform: scale(1.05); box-shadow: 0 6px 20px rgba(255, 217, 61, 0.5); }
    }
    
    /* Star Rating */
    .star-rating {
        color: #FFD93D;
        font-size: 1.3em;
        text-shadow: 0 0 10px rgba(255, 217, 61, 0.5);
        animation: starTwinkle 3s ease-in-out infinite;
    }
    
    @keyframes starTwinkle {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
    }
    
    /* Streaming Badges */
    .streaming-badge {
        display: inline-block;
        padding: 10px 20px;
        margin: 6px;
        border-radius: 25px;
        font-weight: 700;
        font-size: 0.9em;
        font-family: 'Rajdhani', sans-serif;
        transition: all 0.3s ease;
        text-decoration: none;
        border: 2px solid transparent;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        position: relative;
        overflow: hidden;
    }
    
    .streaming-badge::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left 0.5s;
    }
    
    .streaming-badge:hover {
        transform: translateY(-3px) scale(1.05);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }
    
    .streaming-badge:hover::before {
        left: 100%;
    }
    
    .available-service {
        background: linear-gradient(135deg, #6BCF7F, #4CAF50);
        color: white;
    }
    
    .unavailable-service {
        background: rgba(255, 255, 255, 0.1);
        color: #888;
    }
    
    .ticket-service {
        background: linear-gradient(135deg, #FF6B00, #FF8C00);
        color: white;
    }
    
    .anime-service {
        background: linear-gradient(135deg, #F47521, #FF9A3D);
        color: white;
    }
    
    /* Watch Now Section */
    .watch-now-section {
        background: linear-gradient(135deg, 
            rgba(30, 30, 50, 0.9), 
            rgba(40, 40, 60, 0.8));
        border-radius: 18px;
        padding: 25px;
        margin: 20px 0;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.3);
        position: relative;
        overflow: hidden;
    }
    
    .watch-now-section::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
        animation: radar 8s linear infinite;
    }
    
    @keyframes radar {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    /* Sidebar Enhancements */
    .css-1d391kg, .css-1lcbmhc {
        background: rgba(12, 12, 12, 0.9) !important;
        backdrop-filter: blur(10px);
        border-right: 1px solid rgba(255, 255, 255, 0.1) !important;
    }
    
    /* Metric Cards */
    .metric-card {
        background: rgba(20, 20, 35, 0.7) !important;
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        transition: all 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-5px);
        border-color: rgba(255, 107, 107, 0.5);
        box-shadow: 0 15px 30px rgba(255, 107, 107, 0.2);
    }
    
    /* Custom Scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #FF6B6B, #FFD93D);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(135deg, #FFD93D, #6BCF7F);
    }
    
    /* Analytics Specific Styles */
    .analytics-hero {
        background: linear-gradient(135deg, 
            rgba(12, 12, 12, 0.95) 0%, 
            rgba(26, 26, 46, 0.9) 50%, 
            rgba(15, 52, 96, 0.85) 100%);
        padding: 3rem 2rem;
        border-radius: 25px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        margin-bottom: 2rem;
        backdrop-filter: blur(20px);
        box-shadow: 
            0 20px 40px rgba(0, 0, 0, 0.5),
            0 0 100px rgba(77, 150, 255, 0.1);
        position: relative;
        overflow: hidden;
    }
    
    .analytics-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
        margin: 20px 0;
    }
    
    .analytics-card {
        background: linear-gradient(135deg, 
            rgba(30, 30, 45, 0.9), 
            rgba(20, 20, 35, 0.9));
        border-radius: 20px;
        padding: 25px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        transition: all 0.4s ease;
        position: relative;
        overflow: hidden;
    }
    
    .analytics-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #FF6B6B, #FFD93D, #6BCF7F);
        background-size: 200% 100%;
        animation: loadingBar 3s ease-in-out infinite;
    }
    
    .analytics-card:hover {
        transform: translateY(-5px);
        box-shadow: 
            0 20px 40px rgba(0, 0, 0, 0.4),
            0 0 60px rgba(255, 107, 107, 0.2);
    }
    
    .stat-number {
        font-size: 3rem;
        font-weight: 900;
        background: linear-gradient(135deg, #FF6B6B, #FFD93D, #6BCF7F);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin: 10px 0;
    }
    
    .stat-label {
        text-align: center;
        font-size: 1.1rem;
        color: #FFD93D;
        font-weight: 600;
    }
    
    .trend-indicator {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 15px;
        font-size: 0.9rem;
        font-weight: 600;
        margin-left: 10px;
    }
    
    .trend-up {
        background: linear-gradient(135deg, #6BCF7F, #4CAF50);
        color: white;
    }
    
    .trend-down {
        background: linear-gradient(135deg, #FF6B6B, #E53935);
        color: white;
    }
    
    .insight-card {
        background: linear-gradient(135deg, 
            rgba(40, 40, 60, 0.8), 
            rgba(30, 30, 50, 0.9));
        border-radius: 15px;
        padding: 20px;
        margin: 15px 0;
        border-left: 4px solid #FFD93D;
    }
    
    .progress-ring {
        transform: rotate(-90deg);
    }
    
    .progress-ring-circle {
        transition: stroke-dashoffset 0.35s;
        transform: rotate(90deg);
        transform-origin: 50% 50%;
    }
    </style>
    
    <div class="particles" id="particles-js"></div>
    
    <script>
    function createParticles() {
        const particles = document.getElementById('particles-js');
        const particleCount = 30;
        
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            const size = Math.random() * 2 + 1;
            const left = Math.random() * 100;
            const animationDuration = Math.random() * 6 + 4;
            const animationDelay = Math.random() * 5;
            
            particle.style.width = `${size}px`;
            particle.style.height = `${size}px`;
            particle.style.left = `${left}vw`;
            particle.style.animationDuration = `${animationDuration}s`;
            particle.style.animationDelay = `${animationDelay}s`;
            
            particles.appendChild(particle);
        }
    }
    
    // Initialize particles when page loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', createParticles);
    } else {
        createParticles();
    }
    </script>
    """, unsafe_allow_html=True)

# -----------------------------
# Main App
# -----------------------------
def main():
    st.set_page_config(
        page_title="CodeFlix", 
        page_icon="🎬", 
        layout="wide", 
        initial_sidebar_state="expanded"
    )
    
    # Initialize everything
    inject_color_bends_background()  # Add ColorBends background first
    inject_advanced_style()          # Then add enhanced CSS
    init_db()
    init_session_state()
    
    # Check environment first
    if not check_environment():
        st.stop()
    
    # Check and seed database if needed
    check_and_seed_database()
    
    # Validate API key
    omdb = RateLimitedOMDbAPI()
    if not omdb.validate_api_key():
        st.error("⚠️ Movie database API key is invalid or not working. Some features may be limited.")
    
    movies_data = get_movies_safe()
    stats = get_stats()
    
    # -----------------------------
    # Enhanced Sidebar with Streaming
    # -----------------------------
    with st.sidebar:
        st.markdown("""
        <div style='text-align: center; padding: 2rem 1rem;'>
            <h1 style='color: #FF6B6B; font-size: 2.5rem; font-weight: 900; margin: 0; font-family: "Orbitron", sans-serif;'>CODEFLIX</h1>
            <p style='color: #FFD93D; font-size: 1rem; margin: 0; font-family: "Rajdhani", sans-serif;'>Your Personal Movie Universe</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        # Enhanced Navigation with Streaming and Anime
        page = st.radio("NAVIGATION", [
            "🏠 DASHBOARD", 
            "➕ ADD MOVIES", 
            "🎬 MY COLLECTION", 
            "🎯 WATCH NOW",
            "🔍 AI FINDER",
            "📊 ANALYTICS"
        ], index=0)
        
        st.markdown("### 📈 LIVE STATS")
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Total Movies", stats['total_movies'])
        with col2:
            st.metric("Watched", stats['watched_count'])
        
        st.markdown(f"**Completion:** {stats['completion_rate']:.1f}%")
        if stats['average_rating'] > 0:
            st.markdown(f"**Avg Rating:** {stats['average_rating']:.1f} ⭐")
        if stats['in_theaters_count'] > 0:
            st.markdown(f"**In Theaters:** {stats['in_theaters_count']} 🎟️")

    # -----------------------------
    # Page Routing
    # -----------------------------
    if page == "🏠 DASHBOARD":
        show_dashboard(movies_data, stats)
    elif page == "➕ ADD MOVIES":
        show_add_movies_page()
    elif page == "🎬 MY COLLECTION":
        show_collection_page(movies_data)
    elif page == "🎯 WATCH NOW":
        show_streaming_page(movies_data)
    elif page == "🔍 AI FINDER":
        show_enhanced_ai_finder_page()
    elif page == "📊 ANALYTICS":
        show_analytics_page(movies_data)

if __name__ == "__main__":
    main()