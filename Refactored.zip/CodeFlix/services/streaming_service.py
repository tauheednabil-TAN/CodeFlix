import logging
from services.anime_service import AnimeIntegration

# -----------------------------
# Enhanced Streaming & Ticketing Services
# -----------------------------
class StreamingServiceFinder:
    def __init__(self):
        self.streaming_services = {
            'netflix': {
                'name': 'Netflix',
                'color': '#E50914',
                'icon': '🎬',
                'base_url': 'https://www.netflix.com/search?q=',
                'availability_check': self.check_netflix_availability
            },
            'amazon': {
                'name': 'Amazon Prime',
                'color': '#00A8E1',
                'icon': '📦',
                'base_url': 'https://www.primevideo.com/search/ref=atv_nb_sr?phrase=',
                'availability_check': self.check_amazon_availability
            },
            'disney': {
                'name': 'Disney+',
                'color': '#113CCF',
                'icon': '🏰',
                'base_url': 'https://www.disneyplus.com/search/',
                'availability_check': self.check_disney_availability
            },
            'hbo': {
                'name': 'HBO Max',
                'color': '#821DE0',
                'icon': '📺',
                'base_url': 'https://play.hbomax.com/search?q=',
                'availability_check': self.check_hbo_availability
            },
            'hulu': {
                'name': 'Hulu',
                'color': '#1CE783',
                'icon': '🍿',
                'base_url': 'https://www.hulu.com/search?q=',
                'availability_check': self.check_hulu_availability
            },
            'apple': {
                'name': 'Apple TV+',
                'color': '#000000',
                'icon': '🍎',
                'base_url': 'https://tv.apple.com/search?term=',
                'availability_check': self.check_apple_availability
            },
            'youtube': {
                'name': 'YouTube Movies',
                'color': '#FF0000',
                'icon': '📹',
                'base_url': 'https://www.youtube.com/results?search_query=',
                'availability_check': self.check_youtube_availability
            },
            'crunchyroll': {
                'name': 'Crunchyroll',
                'color': '#F47521',
                'icon': '🍥',
                'base_url': 'https://www.crunchyroll.com/search?q=',
                'availability_check': self.check_crunchyroll_availability
            }
        }
        
        self.ticketing_services = {
            'fandango': {
                'name': 'Fandango',
                'color': '#FF7300',
                'icon': '🎟️',
                'base_url': 'https://www.fandango.com/search?q=',
                'type': 'tickets'
            },
            'amc': {
                'name': 'AMC Theatres',
                'color': '#FF0000',
                'icon': '🎭',
                'base_url': 'https://www.amctheatres.com/search?q=',
                'type': 'tickets'
            },
            'regal': {
                'name': 'Regal Cinemas',
                'color': '#FFD700',
                'icon': '👑',
                'base_url': 'https://www.regmovies.com/search?q=',
                'type': 'tickets'
            },
            'cinemark': {
                'name': 'Cinemark',
                'color': '#00A4E0',
                'icon': '💙',
                'base_url': 'https://www.cinemark.com/search?q=',
                'type': 'tickets'
            }
        }

    def check_netflix_availability(self, title, year):
        """Mock Netflix availability check"""
        netflix_titles = ["stranger things", "the crown", "wednesday", "squid game", "the irishman", "bird box", 
                         "the gray man", "red notice", "don't look up", "the adam project", "enola holmes"]
        return any(netflix_title in title.lower() for netflix_title in netflix_titles) or random.random() < 0.4

    def check_amazon_availability(self, title, year):
        """Mock Amazon Prime availability check"""
        amazon_titles = ["the boys", "the marvelous mrs. maisel", "jack ryan", "the terminal list", "reacher",
                        "the tomorrow war", "coming 2 america", "the boys in the boat"]
        return any(amazon_title in title.lower() for amazon_title in amazon_titles) or random.random() < 0.5

    def check_disney_availability(self, title, year):
        """Mock Disney+ availability check"""
        disney_titles = ["star wars", "marvel", "pixar", "national geographic", "the simpsons", "black panther",
                        "avatar", "guardians of the galaxy", "the little mermaid", "wish", "elemental"]
        return any(keyword in title.lower() for keyword in disney_titles) or random.random() < 0.3

    def check_hbo_availability(self, title, year):
        """Mock HBO Max availability check"""
        hbo_titles = ["game of thrones", "succession", "the last of us", "euphoria", "house of the dragon",
                     "dune", "the batman", "elvis", "shazam", "blue beetle", "the nun"]
        return any(keyword in title.lower() for keyword in hbo_titles) or random.random() < 0.35

    def check_hulu_availability(self, title, year):
        """Mock Hulu availability check"""
        return random.random() < 0.4

    def check_apple_availability(self, title, year):
        """Mock Apple TV+ availability check"""
        apple_titles = ["ted lasso", "see", "the morning show", "foundation", "for all mankind", "napoleon", "argylle"]
        return any(keyword in title.lower() for keyword in apple_titles) or random.random() < 0.25

    def check_youtube_availability(self, title, year):
        """Mock YouTube Movies availability check"""
        return random.random() < 0.6

    def check_crunchyroll_availability(self, title, year):
        """Mock Crunchyroll availability check"""
        crunchyroll_titles = ["demon slayer", "jujutsu kaisen", "attack on titan", "my hero academia", "one piece",
                            "naruto", "dragon ball", "death note", "hunter x hunter", "fullmetal alchemist", "spy x family",
                            "chainsaw man", "bleach", "one punch man", "tokyo revengers", "jojo's bizarre adventure"]
        return any(keyword in title.lower() for keyword in crunchyroll_titles) or random.random() < 0.7

    def get_streaming_availability(self, title, year):
        """Get streaming availability for a movie"""
        availability = {}
        
        for service_id, service in self.streaming_services.items():
            try:
                is_available = service['availability_check'](title, year)
                availability[service_id] = {
                    'name': service['name'],
                    'available': is_available,
                    'url': f"{service['base_url']}{quote(title)}",
                    'color': service['color'],
                    'icon': service['icon']
                }
            except Exception as e:
                logging.error(f"Error checking {service_id} availability: {e}")
                availability[service_id] = {
                    'name': service['name'],
                    'available': False,
                    'url': f"{service['base_url']}{quote(title)}",
                    'color': service['color'],
                    'icon': service['icon']
                }
        
        return availability

    def get_ticketing_links(self, title, year):
        """Get ticketing links for movies in theaters"""
        ticketing_links = {}
        
        for service_id, service in self.ticketing_services.items():
            ticketing_links[service_id] = {
                'name': service['name'],
                'url': f"{service['base_url']}{quote(title)}",
                'color': service['color'],
                'icon': service['icon'],
                'type': 'tickets'
            }
        
        return ticketing_links

    def is_movie_in_theaters(self, year):
        """Check if movie is likely in theaters (released in current or previous year)"""
        current_year = datetime.now().year
        return year >= current_year - 1

    def get_watch_options(self, title, year, genre):
        """Get all watch options including streaming and ticketing"""
        watch_options = {
            'streaming': self.get_streaming_availability(title, year),
            'ticketing': {},
            'in_theaters': self.is_movie_in_theaters(year)
        }
        
        if watch_options['in_theaters']:
            watch_options['ticketing'] = self.get_ticketing_links(title, year)
        
        return watch_options

# -----------------------------
# Enhanced StreamingServiceFinder with Anime Support
# -----------------------------
class EnhancedStreamingServiceFinder(StreamingServiceFinder):
    def __init__(self):
        super().__init__()
        self.anime_integration = AnimeIntegration()
        
    def get_watch_options(self, title, year, genre):
        """Enhanced watch options with anime support"""
        watch_options = super().get_watch_options(title, year, genre)
        
        # Add anime streaming if it's anime content
        if self._is_anime_content(title, genre):
            anime_results = self.anime_integration.search_anime(title)
            if anime_results:
                watch_options['anime'] = {
                    'crunchyroll': {
                        'name': 'Crunchyroll',
                        'available': True,
                        'url': anime_results[0]['url'],
                        'color': '#F47521',
                        'icon': '🍥',
                        'type': 'anime'
                    }
                }
        
        return watch_options
    
    def _is_anime_content(self, title, genre):
        """Check if content is likely anime"""
        anime_keywords = ['anime', 'demon slayer', 'jujutsu kaisen', 'attack on titan', 
                         'my hero academia', 'one piece', 'naruto', 'dragon ball', 'death note',
                         'kimetsu no yaiba', 'shippuden', 'hunter x hunter', 'fullmetal alchemist',
                         'chainsaw man', 'spy x family', 'bleach', 'one punch man', 'jojo']
        
        title_lower = title.lower()
        genre_lower = genre.lower() if genre else ""
        
        return (any(keyword in title_lower for keyword in anime_keywords) or
                'anime' in genre_lower)
